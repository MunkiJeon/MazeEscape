package collection_p;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayNumMain {

	public static void main(String[] args) {
		int [] arr = {45,3,17,56,9,87,453,265,27,91,21,34,66,98,87};
		
		ArrayList two = new ArrayList();
		ArrayList three = new ArrayList();

		for (int i: arr) {
			//System.out.println(i);
			if(i%2==0) {
				two.add(i);
			}
			if(i%3==0) {
				three.add(i);
			}
		}
		Collections.sort(two);
		Collections.sort(three);
		System.out.println(two);
		System.out.println(three);
		
		int [] arr2 = {56,78,92,45,73,25,77,94,75,57,83,85,51,45,72};
		
		ArrayList res = new ArrayList();
		
		String title = "수우미양가";
		for (int i = 0; i <title.length(); i++) {
			//0-가, 1-양, 2-미,3-우,4-수
			res.add(new ArrayList());
		}
		
		for (int i : arr2) {
			if(i<60) {
				((ArrayList)res.get(0)).add(i);
			}else {
				int pos = i/10-5;
				System.out.println(i+","+pos);
				((ArrayList)res.get(pos)).add(i);
			}
		}
		Collections.reverse(res);
		//Collections.sort(res);
		for (int i = 0; i <title.length(); i++) {
			
			ArrayList ar = (ArrayList)res.get(i);
			Collections.sort(ar);
			Collections.reverse(ar);
			System.out.println(title.charAt(i)+":"+   ar);
		}
		
		double dd = 78.333333333333333;
		double dd2 = (double)(int)(dd*100)/100;
		
		System.out.println(dd2);
		/*
		 78.333333333333333
		 7833.3333333333333
		 7833
		 7833.0
		 78.33
		 
		 78.333333333333333 -> 78.33
		 78.666666666666666 -> 78.67
		 * */
		
		
	}

}
