package collection_p;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Set;

public class IteratorMain {

	public static void main(String[] args) {
		Set ss = new HashSet();
		
		ss.add(11);
		ss.add(7);
		ss.add(90);
		ss.add(8);
		ss.add(23);
		ss.add(65);
		
		for (Object object : ss) {
			int i = (int)object;
			System.out.println(i);
			if(i==23) {
				//ss.remove(i); for문 도는 중에는 삭제 불가
			}
		}
		System.out.println(ss);
		ArrayList ar = new ArrayList(ss);
		
		Iterator it = ar.iterator();
		System.out.println(it);
		//System.out.println(it.hasNext());
		//System.out.println(it.next());
		while(it.hasNext()) {
			//System.out.println(it.next());
			int i = (int)it.next();
			System.out.println(i);
			if(i==23) {
				//ss.remove(i);
				it.remove();
			}
		}
		System.out.println(ar);
		System.out.println("------------------------");
		
		ListIterator lit = ar.listIterator(); // 굳이 잘안씀 =  Set안됨, 굳이 후진할일 잘없어서
		while(lit.hasNext()) {
			System.out.println(lit.next());
		}
		System.out.println("------------------------");
		while(lit.hasPrevious()) {
			System.out.println(lit.previous());
		}
		
//		System.out.println("------------------------"); 전진한다음 후진해야함
//		ListIterator lit = ar.listIterator();
//		while(lit.hasNext()) {
//			System.out.println(lit.next());
		
		int[] nums = {34, 56, 12, 43, 90, 89, 654, 43, 21234, 675, 45};
		
		//2의 배수 , 3의배수를 제거한 목록을 출력하세요
		Set num = new HashSet();
		for (int oo : nums) {
			num.add(oo);
		}
		Iterator linum = num.iterator();
		while(linum.hasNext()) {
			
			int i = (int)linum.next();
			if(i%2 == 0 || i%3 == 0) {
				linum.remove();
			}
		}
		System.out.println("------------------------");
		System.out.println(num);
	}
}
