package collection_p;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class StackQMain {

	public static void main(String[] args) {
		Stack st = new Stack();	//
		Queue qq = new LinkedList();				//인터 페이스
	
//		st.add(10);
//		st.add(20);
//		st.add(30);
//		
//		qq.add(10);
//		qq.add(20);
//		qq.add(30);
		
		st.push(11);
		st.push(22);
		st.push(33);
		
		qq.offer(100);
		qq.offer(200);
		qq.offer(300);
		
		
//		System.out.println(st);
//		System.out.println(qq);
//
//		Object oo = st.pop();
//		System.out.println(st);
//		System.out.println(oo);
//		oo = st.pop();
//		System.out.println(st);
//		System.out.println(oo);
//		oo = st.pop();
//		System.out.println(st);
//		System.out.println(oo);
//		
//		System.out.println(st.empty());
		
		while(!st.empty()) {
			Object oo = st.pop();
			System.out.println(st);
			System.out.println(oo);
		}
		System.out.println("-----------------------------");
		while(!qq.isEmpty()) {
			Object oo = qq.poll();
			System.out.println(qq);
			System.out.println(oo);
		}
		
	}

}
