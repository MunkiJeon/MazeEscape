package collection_p;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class BaseBollTeam {
/*//기존의 야구팀원리스트--------> 1군리스트
   //2군리스트
   //FA리스트----> FA 가능 리스트

    변경전

   //1군 리스트  박재상, 박정권, 최정, 김광현, 엄정욱, 박희수, 이호준
   //2군 리스트  이호준 , 엄정욱, 박재홍, 이신협, 장동건
   //FA 리스트  이병규,이승엽, 박정권, 장동건, 박용택, 홍성흔

---------------------------------------------------------------------------------------
    변경후

   //1군		박재상, 최정, 김광현, 박희수
   //2군    	이호준 , 엄정욱, 박재홍, 이신협, 
   //FA		이병규,이승엽, 박용택, 홍성흔

 * */
	public static void main(String[] args) {
		Set s1 = new HashSet();
		ArrayList team1 = new ArrayList();
		ArrayList team2 = new  ArrayList();
		ArrayList FA = new  ArrayList();
		
		
	}

}
