package collection_p;

import java.util.*;

class GenShape{
	String name;
	double area, border;
	
	@Override
	public String toString() {
		return name + ">>\t넓이: " + (int)area + "\t둘레" +(int)border;
	}
}
class GenTriangle extends GenShape{
	public GenTriangle(int w, int h, int s) {
		name = "삼각형";
		area = w* h/2;
		border = w+h+s;
	}
}

class GenRectangle extends GenShape{
	public GenRectangle(int w, int h) {
		name = "직사각형";
		area = w* h;
		border = (w+h)*2;
	}
}

class GenCircle extends GenShape{
	public GenCircle(int r) {
		name = "원";
		area = Math.PI*r*r;
		border = Math.PI*r*2;
	}
}



class GenShapeCom implements Comparator<GenShape>{
	@Override
	public int compare(GenShape o1, GenShape o2) {

		int res = o1.name.compareTo(o2.name);
		if(res==0) {
			res = (int) (o2.area - o1.area);
		}
		if(res==0) {
			res = (int) (o2.border - o1.border);
		}
		
		return res;
	}
}


public class GenShapeMain {

	public static void main(String[] args) {
		/*
		 도형별로 나누어 정렬하여 출력하세요
		 
		 구분 : 도형이름
		 정렬순서 : 넓이 > 둘레  내림차순 기준
		 
		 
		 * */
		
		TreeSet<GenShape> arr = new TreeSet<GenShape>(new GenShapeCom());
		arr.add(new GenRectangle(5,6));
		arr.add(new GenCircle(5));
		arr.add(new GenTriangle(5,5,5));
		arr.add(new GenRectangle(10,6));
		arr.add(new GenCircle(8));
		arr.add(new GenTriangle(7,7,7));
		arr.add(new GenCircle(10));
		arr.add(new GenRectangle(8,7));
		arr.add(new GenTriangle(10,6,5));
		
		Iterator<GenShape>it = arr.iterator();
//		Iterator it = arr.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
			
		
		
	}

}
