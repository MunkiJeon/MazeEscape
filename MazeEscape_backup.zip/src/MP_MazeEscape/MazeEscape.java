package MP_MazeEscape;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MazeEscape extends JFrame implements KeyListener, MouseListener {
	JPanel topArea, midArea, botArea, map, player;
	JLabel box, enermy, player_img, map_img;

	int Pan_X = 1000, Pan_Y = 800,
		
		x_m = -1010, y_m = -1630;
	
	String [] P_Images= {"MazeEscape_img/Player/stop_L.gif","MazeEscape_img/Player/stop_R.gif",
						"MazeEscape_img/Player/walk_L.gif","MazeEscape_img/Player/walk_R.gif",
						"MazeEscape_img/Player/proneStab_L.gif","MazeEscape_img/Player/proneStab_R.gif",
						"MazeEscape_img/Player/rope.gif","MazeEscape_img/Player/dead.gif"};
	ImageIcon P_Icon = new ImageIcon(P_Images[0]);
	int P_Ic_X=P_Icon.getIconWidth()+5,P_Ic_Y=P_Icon.getIconHeight()+5,
		P_X = Pan_X-P_Ic_X-25, P_Y = Pan_Y-P_Ic_Y-50;
	
	String [] Map_img= {"MazeEscape_img/Map/Dark_map.png",
			};
	ImageIcon map_IC = new ImageIcon(Map_img[0]);

	public MazeEscape(String Game_Name) {	//기본 배경 설정
		super(Game_Name);
//		setLayout(new BorderLayout());
		setBounds(200,20,Pan_X,Pan_Y);
		setLayout(null);
		

		player = new JPanel();
		player.setBounds(P_X, P_Y, P_Icon.getIconWidth()+5,P_Icon.getIconHeight()+5);
		player.setOpaque(false);
//		player.setBackground(Color.yellow);
		
//		P_Icon = new ImageIcon("MazeEscape_img/Player/stop.gif");//아이콘 변경시 적용법
		System.out.println("세로:"+P_Icon.getIconHeight()+ ", 가로:"+P_Icon.getIconWidth()+", 이미지:"+P_Icon.getImage());
		
		player_img = new JLabel(P_Icon);
		player.add(player_img);
		add(player);
		
		map = new JPanel();
		map.setBounds(x_m,y_m,map_IC.getIconWidth(),map_IC.getIconHeight());
		map.setOpaque(true);
//		map.setBackground(Color.BLACK);
		
		map_img = new JLabel(new ImageIcon(Map_img[0]));
		map.add(map_img);
		add(map);
		
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addKeyListener(MazeEscape.this);
		addMouseListener(this);
	}
	
	class Timer extends Thread{			//게임 내부의 시간
		@Override
		public void run() {
			// TODO Auto-generated method stub
			super.run();
		}
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
		//System.out.println(key);
		switch(key){
		case 37:
			if(P_X >= 5){
				P_X-=5;
				x_m+=5;
				
		
			}
//			System.out.println("왼쪽");
			break;
		case 39:
			if(P_X <= Pan_X-70){
				P_X+=5;
				x_m-=5;
				

			}
			
//			System.out.println("오른쪽");
			break;
		case 38:
			if(P_Y >= 5){
				P_Y-=5;
				y_m+=5;
				
			}
			
			
//			System.out.println("위");
			break;
		case 40:
			
			if(P_Y <= Pan_Y-90){
				P_Y+=5;
				y_m-=5;
				

			}
			
//			System.out.println("아래");
			break;
		}
		player.setLocation(P_X,P_Y);
		map.setLocation(x_m,y_m);
//		System.out.println("pl : "+player.getX()+","+player.getY()+"\nmap : "+map.getX()+","+map.getY());
		//box.setLocation(200, 100);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub	
	}
	
	public static void main(String[] args) {
		new MazeEscape("Potato MazeEscape");

	}
//--------------------------------------------------------------
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("판넬 좌표 :"+e.getX()+","+e.getY());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
