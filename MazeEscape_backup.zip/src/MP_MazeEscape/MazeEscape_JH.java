package MazePro;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import MazePro.MazeEscape_JM.Timer;

public class MazeEscape_JH extends JFrame implements KeyListener, MouseListener {
	JPanel titleBar, Item_State, Player, Feature, MapPan;
	JLabel HP_lb, Item_lb,key_lb,speed_lb,heart_lb,Time, player_img, map_lb, FT_LB;
	JButton restartBtn, startBtn, finishBtn, restartBtnOnPopup;
	
	Timer timeRun = new Timer();
	
	int Pan_X = 800, Pan_Y = 600, Limit = 3, AddTime=10, 
		Map_X = -1014, Map_Y = -1625, MapSize_X = 2000,MapSize_Y = 2400,base_y=1420,base_y2=1920,base_y3=910,base_y4=395;
	
	boolean gameState = false, ddd = false;
	
	String [] Player_img= {"Player/stop_L.gif","Player/stop_R.gif",
						"Player/walk_L.gif","Player/walk_R.gif",
						"Player/proneStab_L.gif","proneStab_R.gif",
						"Player/rope.gif","Player/dead.gif"};
	ImageIcon player_IC = new ImageIcon("MazeEscape_img (1)/"+Player_img[0]);
	
	int player_Ic_X=player_IC.getIconWidth()+5,player_Ic_Y=player_IC.getIconHeight()+5,
		player_X = Pan_X/2-player_Ic_X, player_Y = Pan_Y/2-player_Ic_Y;
	
	String [] feature_img= {"Base.png"
	};
	
	String [] block_img = {
			"block/yellow_block_new.png",
			"block/yellow_block.png",
			"block/purple_block.png",
			"block/big_purple_block.png"
			};
	
	String [] ladder_img = {
			"ladder/blue_ladder_7.png",
			"ladder/blue_ladder_9.png",
			"ladder/blue_ladder_13.png",
			"ladder/yellow_ladder_5.png",
			"ladder/yellow_ladder_7.png",
			"ladder/red_ladder_11.png"
	};
	
	String [] dcr_images = {
			"decobox/onebox_1.png",
			"decobox/onebox_2.png",
			"decobox/onebox_3.png",
			"decobox/twoBox.png",
			"decobox/threebox.png"
			};
	
	String [] Map_img= {"MazeEscap"
			+ "e_img (1)/Map/Dark_map_00.png",
			};
	
	class Feature_lb extends JLabel{
		
		public Feature_lb(int x, int y, String img) {
			ImageIcon ICon = new ImageIcon("MazeEscape_img (1)/Map/feature/"+img);
			
			int IC_X=ICon.getIconWidth()+5,IC_Y=ICon.getIconHeight()+5;
			setIcon(ICon);
			setBounds(x,y,IC_X,IC_Y);
			setOpaque(false);
			
//			System.out.println("블럭 경로:"+ICon+"\nX,Y 좌표:"+x+","+y+"\n블럭 크기:"+IC_X+","+IC_Y);
		}
		public Feature_lb( int y, String img) {
			ImageIcon ICon = new ImageIcon("MazeEscape_img (1)/Map/"+img);
			
			int IC_X=ICon.getIconWidth(),IC_Y=ICon.getIconHeight();
			setIcon(ICon);
			
			setBounds(0,y,IC_X,IC_Y);
			setOpaque(false);
			
		}
	}

	public MazeEscape_JH() {	//기본 배경 설정
		super("Potato MazeEscape");
		
		JDialog StartPopup = new JDialog(this, "Potato MazeEscape", true);
		StartPopup.setBounds(Pan_X/2, Pan_Y/2, 300, 100);
		StartPopup.setLayout(new FlowLayout());
		
		StartPopup.add(new JLabel("게임을 시작하려면 아래 버튼을 눌러주세요."));
		startBtn = new JButton("게임 시작");
		StartPopup.add(startBtn);
		
		//타이머 쓰레드 도는 구간 
		startBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gameState = true;
				StartPopup.dispose();
				timeRun.start();

			}
		});
		
		StartPopup.setLocationRelativeTo(null);
		StartPopup.setVisible(true);
		//--------시작 팝업 끝
		
		setBounds(0, 0, Pan_X, Pan_Y);
		setLayout(null);
		
		//--------타이틀바 영역 시작
		titleBar = new JPanel();
		titleBar.setBounds(0, 0, Pan_X, 30);
		getContentPane().add(titleBar);
		titleBar.setBackground(new Color(0,0,0,0));
		titleBar.setLayout(null);
		
		restartBtn = new JButton("재시작");
		restartBtn.setBounds(0, 0, 90, 30);
		titleBar.add(restartBtn);
		
		//////////////////////////////////////////////
		restartBtn.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("재시작!!!");
				Map_X = -1219; Map_Y = -1630;
				map_lb.setLocation(-1219,-1630);	
			}
		});
		restartBtn.setFocusable(false);
		
		//// 종현 작업

		// fisnishPopup창에서의 재시작
		restartBtnOnPopup = new JButton("다시 도전");
		restartBtnOnPopup.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("다시 도전");
				Map_X = -1219; Map_Y = -1630;
				map_lb.setLocation(-1219,-1630);
				gameState = false;
				//timeRun.stop();
			}
		});
		// gameState상태를 다시 true로 바꿔줌
		if (gameState == false) {
			gameState=true;	
		}
		restartBtnOnPopup.setFocusable(false);
		
		// ------------프로그램 종료
		finishBtn = new JButton("프로그램 종료");
		finishBtn.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("프로그램 종료");
				gameState = false;
				System.exit(0);
			}
		});
		finishBtn.setFocusable(false);
		
		// ========시간추가 테스트
		JButton TaddBtn = new JButton("+Time");
		TaddBtn.setBounds(50, 0, 90, 30);
		titleBar.add(TaddBtn);
		TaddBtn.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("시간 추가");
				System.out.println(ddd);
				ddd = true;
				System.out.println(ddd);
			}
		});
		TaddBtn.setFocusable(false);
		
		Item_State = new JPanel();
		Item_State.setBounds(240, 0, 364, 30);
		Item_State.setBackground(Color.WHITE);
		titleBar.add(Item_State);
		Item_State.setLayout(null);
		
		Item_lb = new JLabel("Item :");
		Item_lb.setBounds(10, 0, 35, 30);
		Item_State.add(Item_lb);
		
		speed_lb = new JLabel("X n");
		speed_lb.setIcon(new ImageIcon("MazeEscape_img (1)/Item/boot.png"));
		speed_lb.setBounds(70, 0, 67, 30);
		Item_State.add(speed_lb);
		
		key_lb = new JLabel("X n");
		key_lb.setIcon(new ImageIcon("MazeEscape_img (1)/Item/key.png"));
		key_lb.setBounds(170, 0, 67, 30);
		Item_State.add(key_lb);
		
		Time = new JLabel(">  " + Limit+"초 <");
		Time.setIcon(new ImageIcon("MazeEscape_img (1)/Item/SandTimer.png"));
		Time.setBounds(270, 0, 123, 30);
		Item_State.add(Time);
	
		//--------타이틀바 영역 끝
		
		//--------케릭터 영역 시작
		Player = new JPanel();
		Player.setBounds(player_X, player_Y, player_Ic_X,player_Ic_Y);
		Player.setBackground(new Color(255,0,0,0));
		Player.setOpaque(false);
		player_img = new JLabel(player_IC);
		Player.add(player_img);
		add(Player);
		
		//--------케릭터 영역 끝
	
		//--------맵 영역 시작
		MapPan = new JPanel();
		MapPan.setBounds(Map_X, Map_Y, MapSize_X, MapSize_Y);
		MapPan.setLayout(getLayout());
		
		map_lb = new JLabel();
		map_lb.setIcon(new ImageIcon(Map_img[0]));
		map_lb.addMouseListener(this);
 		
		//--------지형지물 추가 영역 시작
		// 1층 먭 (setBackground를 준 이유는 사다리 탈때 색을 보고 확인하려고)
		MapPan.add(new Feature_lb(1920,feature_img[0]));
		
		MapPan.add(new Feature_lb(1205,1735,ladder_img[0])).setBackground(Color.blue);	
		MapPan.add(new Feature_lb(1535,1695,dcr_images[0]));
		MapPan.add(new Feature_lb(1200,1735,block_img[0]));
		
		MapPan.add(new Feature_lb(369,1735,ladder_img[0])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(310,1735,block_img[1]));
		
		MapPan.add(new Feature_lb(890,1495,ladder_img[1])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(1194,1500,ladder_img[3])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(854,1500,block_img[0]));
		
		MapPan.add(new Feature_lb(1190,1630,block_img[0]));
		
		/// 2층 맵
		MapPan.add(new Feature_lb(1540,1410,ladder_img[1])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(1420,feature_img[0]));
		
		MapPan.add(new Feature_lb(560,1280,ladder_img[3])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(400,1280,block_img[0]));
		
		MapPan.add(new Feature_lb(475,1032,ladder_img[5])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(420, 953 ,dcr_images[4]));
		MapPan.add(new Feature_lb(400,1032,block_img[2]));
		
		MapPan.add(new Feature_lb(757,990,ladder_img[2])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(755, 955, dcr_images[2]));
		MapPan.add(new Feature_lb(700, 990, block_img[2]));
		
		MapPan.add(new Feature_lb(1260,1227,ladder_img[4])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(950,1230,block_img[1]));
		
		MapPan.add(new Feature_lb(1000,1095,ladder_img[3])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(925,1095,block_img[0]));
		
		MapPan.add(new Feature_lb(1530,1095,ladder_img[3])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(1450, 1055, dcr_images[1]));
		MapPan.add(new Feature_lb(1435,1095,block_img[2]));
		
		/// 3층 맵
		MapPan.add(new Feature_lb(1200,900,ladder_img[4])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(910,feature_img[0]));
		MapPan.add(new Feature_lb(1512, 870, dcr_images[2]));
		
		MapPan.add(new Feature_lb(1000,751,ladder_img[3])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(830,751,block_img[1]));
		
		MapPan.add(new Feature_lb(830,509,ladder_img[1])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(300,519,block_img[3]));
		
		MapPan.add(new Feature_lb(1430,519,ladder_img[1])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(1484, 441, dcr_images[3]));
		MapPan.add(new Feature_lb(1418,519,block_img[2]));
		
		
		//MapPan.add(new Feature_lb(base_y4,feature_img[0]));
		
		/// 4층 맵
		MapPan.add(new Feature_lb(383,385,ladder_img[3])).setBackground(Color.blue);
		MapPan.add(new Feature_lb(395,feature_img[0]));
		
		MapPan.add(map_lb);
		add(MapPan);
		//--------지형지물 추가 영역 끝
		
		setVisible(true);
		setResizable(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addKeyListener(this);
	}
		
	
	int nowtime=0;
	class Timer extends Thread{			//게임 내부의 시간
		@Override
		public void run() {
			String fns = "";
			//닫기 팝업
			Dialog finishPopup = new JDialog();
			finishPopup.setBounds(750, 450, 400, 100);
			finishPopup.setLayout(new FlowLayout());
			while(gameState) {	
				Time = new JLabel();
				for (int i = Limit; i >= 0; i--) {
//					System.out.println(i+"초");
					if(ddd==true) {
						i += AddTime;
					}
					ddd=false;
					
					Time.setText((i)+"초");
					
					if (i==0) {
						fns = "끝";	
						System.out.println(fns);
						
						finishPopup.add(new JLabel("시간초과!! 다시 시작하고 싶다면 재시작 버튼을 눌러주세요"));
						finishPopup.setVisible(true);
						
						finishPopup.add(restartBtnOnPopup);
						finishPopup.add(finishBtn);
						
						finishPopup.setVisible(true);
						
					}
					
					try {
						sleep(1000);
						if (fns=="끝") {
							break;
						}
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}	
			gameState = false;
			finishPopup.dispose();	
			
			
		}
	}
	

//--------------------------------------------------------------
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
//		System.out.println(key);
		switch(key){
		case 37:
			if(Map_X<=-4){
				Map_X +=5;
				player_img.setIcon(new ImageIcon("MazeEscape_img (1)/"+Player_img[2]));
				
			}
			break;
		case 39:
			if(Map_X>=-1215){
				player_img.setIcon(new ImageIcon("MazeEscape_img (1)/"+Player_img[3]));
				Map_X -=5;
			}
			break;
		case 38:
			if(Map_Y <=-95){
				player_img.setIcon(new ImageIcon("MazeEscape_img (1)/"+Player_img[6]));
				Map_Y+=5;
			}
			break;
		case 40:
			if(Map_Y==-1125||Map_Y==-615||Map_Y==-100) {
				Map_Y+=5;
			} 
			if(Map_Y > -1625){
				player_img.setIcon(new ImageIcon("MazeEscape_img (1)/"+Player_img[6]));
				Map_Y-=5;
				
			}
			break;
		}
		Player.setLocation(player_X,player_Y);
		MapPan.setLocation(Map_X,Map_Y);
		
		
		System.out.println("map : "+map_lb.getX()+","+map_lb.getY()+"\npl :"+Player.getX()+","+Player.getY());
		System.out.println("mappan:"+MapPan.getY());
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(player_img.getIcon().equals("MazeEscape_img (1)/"+Player_img[3])){
			player_img.setIcon(new ImageIcon("MazeEscape_img (1)/"+Player_img[1]));
		}else {
			player_img.setIcon(new ImageIcon("MazeEscape_img (1)/"+Player_img[0]));
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Map 좌표 :"+e.getX()+","+e.getY());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
//--------------------------------------------------------------
	public static void main(String[] args) {
		
		new MazeEscape_JH();
	}
}
