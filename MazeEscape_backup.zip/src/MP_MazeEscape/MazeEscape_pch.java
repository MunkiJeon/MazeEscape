package swing_p;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import swing_p.MazeEscape_ch.Feature_lb;



public class MazeEscape_pch extends JFrame implements KeyListener, MouseListener,ActionListener {
	

	JPanel titleBar, Item_State, Player, Feature, Map,finish,Char_ax;
	JLabel HP_lb, Item_lb,key_lb,speed_lb,heart_lb,Time, player_img, map_lb, FT_LB,item_boot,item_boot2,item_key,item_Stime,item_Stime2,item_Stime3;
	JButton restartBtn,WinBtn,finishBtn;

	Timer tt = new Timer();
	
	int Pan_X = 800, Pan_Y = 600, 
		Map_X = -1014, Map_Y = -1625, MapSize_X = 2000,MapSize_Y = 2400,Limit=60,AddTime=10,base_y=1420,base_y2=1920,base_y3=910,base_y4=395;
	
	int  Speed=5,i=0,t=0,k=0;
	boolean gameState = true,ddd = false;
	
	
	String [] Player_img= {"Player/stop_L.gif","Player/stop_R.gif",
						"Player/walk_L.gif","Player/walk_R.gif",
						"Player/proneStab_L.gif","proneStab_R.gif",
						"Player/rope.gif","Player/dead.gif"};
	ImageIcon player_IC = new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[0]);
	
	ImageIcon im,im2,im3;
	
	String [] block_img = {"block/yellow_block_new.png","block/yellow_block.png",
			"block/purple_block.png","block/big_purple_block.png","block/Base.png"
			};
	
	String [] ladder_img = {"ladder/blue_ladder_7.png","ladder/blue_ladder_9.png",
			"ladder/blue_ladder_13.png","ladder/yellow_ladder_5.png",
			"ladder/yellow_ladder_7.png","ladder/red_ladder_11.png"
			};
	
	String [] dcr_images = {
			"decobox/onebox_1.png","decobox/onebox_2.png","decobox/onebox_3.png",
			"decobox/twoBox.png","decobox/threebox.png"
			};
	
	int player_Ic_X=player_IC.getIconWidth()+5,player_Ic_Y=player_IC.getIconHeight()+5,
		player_X = Pan_X/2-player_Ic_X, player_Y = Pan_Y/2-player_Ic_Y;
	
	String [] feature_img= {"Base.png"
	};
	
	String [] Map_img= {"ff/MazeEscap"
			+ "e_img (1)/Map/Dark_map_00.png",
			};
	
	Object [][] feature_Block= {
			{0,1920,block_img[4]},{0,1420,block_img[4]},{0,910,block_img[4]},{0,395,block_img[4]},
			{1200,1735,block_img[0]},{310,1735,block_img[1]},{854,1500,block_img[0]},{1190,1630,block_img[0]},
			{400,1280,block_img[0]},{400,1032,block_img[2]},{700, 990, block_img[2]},{950,1230,block_img[1]},
			{925,1095,block_img[0]},{1435,1095,block_img[2]},{830,751,block_img[1]},{300,519,block_img[3]},
			{1418,519,block_img[2]}
	};
	Object [][] feature_ladder= {
			{1205,1735,ladder_img[0]},{369,1735,ladder_img[0]},{890,1495,ladder_img[1]},{1194,1500,ladder_img[3]},
			{1540,1410,ladder_img[1]},{560,1280,ladder_img[3]},{475,1032,ladder_img[5]},{757,990,ladder_img[2]},
			{1260,1227,ladder_img[4]},{1000,1095,ladder_img[3]},{1530,1095,ladder_img[3]},{1200,900,ladder_img[4]},
			{1000,751,ladder_img[3]},{830,509,ladder_img[1]},{1430,519,ladder_img[1]},{383,385,ladder_img[3]}
	};
	Object [][] feature_dcr= {
			{1535,1695,dcr_images[0]},{369,1735,ladder_img[0]},{420, 953 ,dcr_images[4]},{755, 955, dcr_images[2]},
			{1450, 1055, dcr_images[1]},{1512, 870, dcr_images[2]},{1484, 441, dcr_images[3]}
	};
	
	class Feature_lb extends JLabel{
		int x,y;
		String img;
		public Feature_lb(Object x, Object y, Object img) {
			this.img = (String)(img);
			this.x = (int)(x);
			this.y = (int)(y);
			ImageIcon ICon = new ImageIcon("ff/MazeEscape_img (1)/Map/feature/"+this.img);
			
			int IC_X=ICon.getIconWidth()+5,IC_Y=ICon.getIconHeight()+5;
			setIcon(ICon);
			setBounds(this.x,this.y,IC_X,IC_Y);
			setOpaque(false);
			
//			System.out.println("���� ���:"+ICon+"\nX,Y ��ǥ:"+x+","+y+"\n���� ũ��:"+IC_X+","+IC_Y);
		}
		public Feature_lb( int y, String img) {
			ImageIcon ICon = new ImageIcon("ff/MazeEscape_img (1)/Map/"+img);
			
			int IC_X=ICon.getIconWidth(),IC_Y=ICon.getIconHeight();
			setIcon(ICon);
			
			setBounds(0,y,IC_X,IC_Y);
			setOpaque(false);
			
		}
	}
	


	public MazeEscape_pch() {	//�⺻ ��� ����
		super("Potato MazeEscape");
		
		JDialog StertPopup = new JDialog(this, "Potato MazeEscape", true);
		StertPopup.setBounds(Pan_X/2, Pan_Y/2, 300, 100);
		StertPopup.setLayout(new FlowLayout());
		
		StertPopup.add(new JLabel("������ �����Ϸ��� �Ʒ� ��ư�� �����ּ���."));
		JButton sbtn = new JButton("���� ����");
		StertPopup.add(sbtn);
		sbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				gameState = true;
				StertPopup.dispose();	
				Timer timeRun = new Timer();
				timeRun.start();
			
			}
		});
		tt.start();
		StertPopup.setLocationRelativeTo(null);
		StertPopup.setVisible(true);
		//--------���� �˾� ��
		
		setBounds(0, 0, Pan_X, Pan_Y);
		setLayout(null);
		
		//--------Ÿ��Ʋ�� ���� ����
		titleBar = new JPanel();
		titleBar.setBounds(0, 0, Pan_X, 30);
		getContentPane().add(titleBar);
		titleBar.setBackground(new Color(0,0,0,0));
		titleBar.setLayout(null);
		
		finishBtn = new JButton("���α׷� ����");
		finishBtn.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("���α׷� ����");
				gameState = false;
				System.exit(0);
			}
		});
		finishBtn.setFocusable(false);
		
		///������ ���α׷� ����
				WinBtn = new JButton("����");
				WinBtn.addActionListener(new AbstractAction() {
					@Override
					public void actionPerformed(ActionEvent e) {
						System.exit(0);
					}
				});
		
		Item_State = new JPanel();
		Item_State.setBounds(240, 0, 364, 30);
		Item_State.setBackground(new Color(178,204,255));
		titleBar.add(Item_State);
		Item_State.setLayout(null);
		
//		HP_lb = new JLabel("HP :");
//		HP_lb.setBounds(0, 0, 35, 30);
//		Item_State.add(HP_lb);
		im = new ImageIcon("ff/MazeEscape_img (1)/Item/booot1.png");
		im2 = new ImageIcon("ff/MazeEscape_img (1)/Item/key.png");
		im3 = new ImageIcon("ff/MazeEscape_img (1)/Item/SandTimer.png");
//		---------------------������ ���
		item_boot = new JLabel(im);
		item_boot.setBounds(400, 970, 100, 100);
		//��
		item_boot2 = new JLabel(im);
		item_boot2.setBounds(1250, 450, 100, 100);
		//��
		item_Stime = new JLabel(im3);
		item_Stime.setBounds(1535, 1680, 100, 100);
		//��
		item_Stime2 = new JLabel(im3);
		item_Stime2.setBounds(1450, 1030, 100, 100);
		
		item_Stime3 = new JLabel(im3);
		item_Stime3.setBounds(400, 840, 100, 100);
		
		item_key = new JLabel(im2);
		item_key.setBounds(1484, 460, 100, 100);
		//��
		finish = new JPanel();
		finish.setBounds(1400, 1850, 100, 100);
		finish.setBackground(Color.black);
		finish.setOpaque(true);
		
		
		Item_lb = new JLabel("Item :");
		Item_lb.setBounds(10, 0, 35, 30);
		Item_State.add(Item_lb);
		
		speed_lb = new JLabel("X ");
		speed_lb.setIcon(new ImageIcon("ff/MazeEscape_img (1)/Item/boot.png"));
		speed_lb.setBounds(70, 0, 67, 30);
		Item_State.add(speed_lb);
		
		key_lb = new JLabel("X ");
		key_lb.setIcon(new ImageIcon("ff/MazeEscape_img (1)/Item/key.png"));
		key_lb.setBounds(170, 0, 67, 30);
		Item_State.add(key_lb);
		
		Time = new JLabel("> "+Limit+"�� <");
		Time.setIcon(new ImageIcon("ff/MazeEscape_img (1)/Item/SandTimer.png"));
		Time.setBounds(270, 0, 123, 30);
		Item_State.add(Time);
		
//		heart_lb = new JLabel("X n");
//		heart_lb.setIcon(new ImageIcon("MazeEscape_img/Item/heart.png"));
//		heart_lb.setBounds(46, 0, 67, 30);
//		Item_State.add(heart_lb);
		

		//--------Ÿ��Ʋ�� ���� ��
		
		//--------�ɸ��� ���� ����
		Player = new JPanel();
		Player.setBounds(player_X, player_Y, player_Ic_X,player_Ic_Y);
		Player.setBackground(new Color(255,0,0,0));
		Player.setOpaque(false);
		player_img = new JLabel(player_IC);
		Player.add(player_img);
		add(Player);
		
		//--------�ɸ��� ���� ��
		
		//--------�������� �߰� ���� ����
		
//		Feature = new JPanel();
//		Feature.setBounds(Map_X,Map_Y, MapSize_X, MapSize_Y);
//		Feature.setBackground(new Color(255,255,0));
//		Feature.setLayout(null);
//		Feature.setOpaque(false);
//		Feature.add(new Feature_lb(-500,feature_img[0])); //����
//		Feature.add(new Feature_lb(0,-222,"block/yellow_block2.png")); //����
//		add(Feature);
		
		
		//add(new Feature_lb(base_y,feature_img[0])); //����
		
		
		//--------�������� �߰� ���� ��

		Map = new JPanel();
		Map.setBounds(Map_X,Map_Y, MapSize_X, MapSize_Y);
		Map.setLayout(getLayout());
		
		Char_ax = new JPanel();
		Char_ax.setBackground(Color.RED);
		Char_ax.setBounds(1375+player_Ic_Y/4,1925-player_Ic_Y, 10, player_Ic_Y);
		System.out.println("ic_size :"+player_Ic_Y+","+Char_ax.getBounds().y+","+(Char_ax.getBounds().y+player_Ic_Y));
		Map.add(Char_ax);
		
		
		
		map_lb = new JLabel();
		map_lb.setIcon(new ImageIcon(Map_img[0]));
		
		Map.add(item_boot);
		Map.add(item_boot2);
		Map.add(item_key);
		Map.add(item_Stime);
		Map.add(item_Stime2);
		Map.add(item_Stime3);
		
		for (int i = 0; i < feature_ladder.length; i++) {
			Map.add(new Feature_lb(feature_ladder[i][0],feature_ladder[i][1],feature_ladder[i][2]));
		}
		for(int i = 0; i<feature_dcr.length; i++) {
			Map.add(new Feature_lb(feature_dcr[i][0],feature_dcr[i][1],feature_dcr[i][2]));
		}
		for (int i = 0; i < feature_Block.length; i++) {
			Map.add(new Feature_lb(feature_Block[i][0],feature_Block[i][1],feature_Block[i][2]));
		}
		
		map_lb.addMouseListener(this);
		
		
		add(new Feature_lb(0,-222,"block/yellow_block2.png")); //����
		//base_y=1420,base_y2=1920,base_y3=910,base_y4=395
		map_lb.add(new Feature_lb(1420,feature_img[0]));
		
		map_lb.add(new Feature_lb(1920,feature_img[0]));
		
		map_lb.add(new Feature_lb(910,feature_img[0]));
		
		map_lb.add(new Feature_lb(395,feature_img[0]));
		
		//MapPan.add(new Feature_lb(base_y4,feature_img[0]));
		
		
		
		
		
		
		Map.add(map_lb);
		add(Map);
		
		
		
		setVisible(true);
		setResizable(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		Item tm = new Item();
		Item2 tm2 = new Item2();
		Item3 tm3 = new Item3();
		Item4 tm4 = new Item4();
		Item5 tm5 = new Item5();
		Item6 tm6 = new Item6();
		
		tm.start();
		tm2.start();
		tm3.start();
		tm4.start();
		tm5.start();
		tm6.start();
		
		addKeyListener(this);
	}
	
	class Item extends Thread{			//���� ������ �ð�
		@Override
		public void run() {
			while(true) {
				try {
					sleep(10);
					if(Map.getX()<-1189&&Map.getX()>-1219&&Map.getY()>-1470&&Map.getY()<-1410) {
						Map.remove(item_Stime);
						t+=10;
						break;
					}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			
			
	
			Dialog WinPopup = new JDialog();
            WinPopup.setBounds(750, 450, 400, 100);
            WinPopup.setLayout(new FlowLayout());
            
			while(true) {
				if(Map.getX()>-1114&&Map.getX()<-1039&&k==1) {
					k = 0;
	                System.out.println("����!");
	                WinPopup.add(new JLabel("��翩 Ż���� ���ϵ帳�ϴ�. ���丮�� ���Ϸ���� �������ƿ�!"));
	                WinPopup.add(WinBtn);
						
	                WinPopup.setVisible(true);
				}
	            try {
	               sleep(10);
	          
	               } catch(InterruptedException e) {
	               e.printStackTrace();
	            }
	         }
		}
		
	}
	
	class Item2 extends Thread{
		@Override
		public void run() {
			while(true) {
				try {
					sleep(10);
					if(Map.getX()<-1139&&Map.getX()>-1174&&Map.getY()>-235&&Map.getY()<-190) {
						Map.remove(item_key);
						k+=1;
						key_lb.setText("X"+k);
						break;
					}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	class Item3 extends Thread{
		@Override
		public void run() {
			while(true) {
				try {
					sleep(50);
					if(Map.getX()<-909&&Map.getX()>-934&&Map.getY()>-245&&Map.getY()<-195) {
						Map.remove(item_boot2);
						i+=1;
						speed_lb.setText("X "+i);
						Speed =+(Speed+5);
						break;
					}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}	
		}
	}
	
	
	
	
	class Item4 extends Thread{
		@Override
		public void run() {
			while(true) {
				try {
						sleep(50);
					if((Map.getX()>-89&&Map.getX()<-54&&Map.getY()>-765&&Map.getY()<-720)
							) {
						Map.remove(item_boot);
						i+=1;
						speed_lb.setText("X "+i);
						Speed =+(Speed+5);
						break;
					} 
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	class Item5 extends Thread{
		@Override
		public void run() {
			while(true) {
				try {
					sleep(10);
					if(Map.getX()>-1139&&Map.getX()<-1104&&Map.getY()>-815&&Map.getY()<-780) {
						Map.remove(item_Stime2);
						t+=10;
						break;
					}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	class Item6 extends Thread{
		@Override
		public void run() {

			while(true) {
				try {
					sleep(10);
					if(Map.getX()>-84&&Map.getX()<-54&&Map.getY()>-615&&Map.getY()<-590) {
						Map.remove(item_Stime3);
						t+=10;
						break;
					}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
	int nowtime=0;
	class Timer extends Thread{			
		@Override
		public void run() {
	
			while(true) {	
				Time = new JLabel();
				for ( t = Limit; t >= 0; t--) {
//					System.out.println(i+"��");
					Time.setText((t)+"��");
					try {
						sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
		}
	}
	/*
	public class Music extends Thread{
		private boolean isLoop;
		private F
		public Music(String name, boolean isLoop) {
			try {
				this.isLoop = isLoop;
			}
		}
	}
	*/
	

//--------------------------------------------------------------
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
//		System.out.println(key);
		switch(key){
		case 37:
			if(Map_X<=-4){
				Map_X +=Speed;
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[2]));
				
			}
			break;
		case 39:
			if(Map_X>=-1215){
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[3]));
				Map_X -=Speed;
			}
			break;
		case 38:
			if(Map_Y <=-95){
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[6]));
				Map_Y+=5;
			}
			break;
		case 40:
			if(Map_Y==-1125||Map_Y==-615||Map_Y==-100) {
				Map_Y+=5;
			}
			if(Map_Y > -1625){
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[6]));
				Map_Y-=5;
				
			}
			break;
		}
		Player.setLocation(player_X,player_Y);
		Map.setLocation(Map_X,Map_Y);
		
		
		
		System.out.println("MapY:"+Map.getY()+"mapX:"+Map.getX());
		System.out.println("imax:"+item_boot2.getX()+"imay:"+item_boot2.getY());
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(player_img.getIcon().equals("ff/MazeEscape_img (1)/"+Player_img[3])){
			player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[1]));
		}else {
			player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[0]));
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Map ��ǥ :"+e.getX()+","+e.getY());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
//--------------------------------------------------------------
	public static void main(String[] args) {
		
		new MazeEscape_pch();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

	
}

