package swing_p;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;



public class MazeEscape_ch extends JFrame implements KeyListener, MouseListener {
	JPanel titleBar, Item_State, Player, Feature, MapPan, Map, Char_ax;
	JLabel HP_lb, Item_lb,key_lb,speed_lb,heart_lb, player_img, map_lb, FT_LB, Time_lb,
	// 찬희형 아이템
	item_boot,item_boot2,item_key,item_Stime,item_Stime2,item_Stime3;
	JButton restartBtn, startBtn, finishBtn, WinBtn, restartBtnOnPopup;
	
	Timer timeRun = new Timer();
	
	int Pan_X = 800, Pan_Y = 600, Limit = 300, AddTime=10, 
		Map_X = -1014, Map_Y = -1625, MapSize_X = 2000,MapSize_Y = 2400,base_y=1420,base_y2=1920,base_y3=910,base_y4=395;
	
	//찬추
	int  Speed=5,i=0,t=0,k=0;
	////--------찬추
	
	boolean gameState = false, ddd = false, UD_Break = false, LR_Break;
	
	String [] Player_img= {"Player/stop_L.gif","Player/stop_R.gif",
						"Player/walk_L.gif","Player/walk_R.gif",
						"Player/proneStab_L.gif","proneStab_R.gif",
						"Player/rope.gif","Player/dead.gif"};
	ImageIcon player_IC = new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[0]);
	
	ImageIcon im,im2,im3;
	
	int player_Ic_X=player_IC.getIconWidth()+5,player_Ic_Y=player_IC.getIconHeight()+5,
		player_X = Pan_X/2-player_Ic_X, player_Y = Pan_Y/2-player_Ic_Y;
	
	
	String [] block_img = {
			"block/yellow_block_new.png",
			"block/yellow_block.png",
			"block/purple_block.png",
			"block/big_purple_block.png",
			"block/Base.png"
			};
	
	String [] ladder_img = {
			"ladder/blue_ladder_7.png",
			"ladder/blue_ladder_9.png",
			"ladder/blue_ladder_13.png",
			"ladder/yellow_ladder_5.png",
			"ladder/yellow_ladder_7.png",
			"ladder/red_ladder_11.png"
	};
	
	String [] items_imag = {
			"Item/booot1.png",
			"Item/SandTimer.png",
			"Item/key.png"
	};
	
	String [] dcr_images = {
			"decobox/onebox_1.png",
			"decobox/onebox_2.png",
			"decobox/onebox_3.png",
			"decobox/twoBox.png",
			"decobox/threebox.png"
			};
	
	String [] Map_img= {"ff/MazeEscape_img (1)/Map/Dark_map_00.png",
			};
	
	Object [][] feature_Block= {
			{0,1920,block_img[4]},{0,1420,block_img[4]},{0,910,block_img[4]},{0,395,block_img[4]},
			{1200,1735,block_img[0]},{310,1735,block_img[1]},{854,1500,block_img[0]},{1190,1630,block_img[0]},
			{400,1280,block_img[0]},{400,1032,block_img[2]},{700, 990, block_img[2]},{950,1230,block_img[1]},
			{925,1095,block_img[0]},{1435,1095,block_img[2]},{830,751,block_img[1]},{300,519,block_img[3]},
			{1418,519,block_img[2]}
	};
	Object [][] feature_ladder= {
			{1205,1735,ladder_img[0]},{369,1735,ladder_img[0]},{890,1495,ladder_img[1]},{1194,1500,ladder_img[3]},
			{1540,1410,ladder_img[1]},{560,1280,ladder_img[3]},{475,1032,ladder_img[5]},{757,990,ladder_img[2]},
			{1260,1227,ladder_img[4]},{1000,1095,ladder_img[3]},{1530,1095,ladder_img[3]},{1200,900,ladder_img[4]},
			{1000,751,ladder_img[3]},{830,509,ladder_img[1]},{1430,519,ladder_img[1]},{383,385,ladder_img[3]}
	};
	
	Object [][] feature_dcr= {
			{1535,1695,dcr_images[0]},{369,1735,ladder_img[0]},{420, 953 ,dcr_images[4]},{755, 955, dcr_images[2]},
			{1450, 1055, dcr_images[1]},{1512, 870, dcr_images[2]},{1484, 441, dcr_images[3]}
	};
	
	Object [][] items_featrue={
		{400,970,items_imag[0]},{1250,450,items_imag[0]},{1535,1680,items_imag[1]},{1450,1030,items_imag[1]},{400,840,items_imag[1]},
		{1484,460,items_imag[2]}
	};
	
	class Img_arr extends JLabel{
		int x,y;
		String img;
		public Img_arr(Object x, Object y, Object img) {
			this.img = (String)(img);
			this.x = (int)(x);
			this.y = (int)(y);
			ImageIcon ICon = new ImageIcon("ff/MazeEscape_img (1)/"+this.img);
			setIcon(ICon);
			setBounds(this.x, this.y, 100, 100);
			setOpaque(false);
		}
	}
	
	class Feature_lb extends JLabel{
		int x,y;
		String img;
		public Feature_lb(Object x, Object y, Object img) {
			this.img = (String)(img);
			this.x = (int)(x);
			this.y = (int)(y);
			ImageIcon ICon = new ImageIcon("ff/MazeEscape_img (1)/Map/feature/"+this.img);
			
			int IC_X=ICon.getIconWidth()+5,IC_Y=ICon.getIconHeight()+5;
			setIcon(ICon);
			setBounds(this.x,this.y,IC_X,IC_Y);
			setOpaque(false);
		}
		
		
	}
	
	public MazeEscape_ch() {	//기본 배경 설정
		super("Potato MazeEscape");
		
		JDialog StartPopup = new JDialog(this, "Potato MazeEscape", true);
		StartPopup.setBounds(Pan_X/2, Pan_Y/2, 340, 150);
		StartPopup.setLayout(new FlowLayout());
		
		StartPopup.add(new JLabel("스피드 아이템: 스피드+5 | 시간 아이템: 시간+10초"));
		StartPopup.add(new JLabel("★중요★ <열쇠 아이템을 찾아야지만 탈출 할 수 있습니다> "));
		StartPopup.add(new JLabel("게임을 시작하려면 아래 버튼을 눌러주세요."));
		startBtn = new JButton("게임 시작");
		StartPopup.add(startBtn);
		
		//타이머 쓰레드 도는 구간 
		startBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gameState = true;
				StartPopup.dispose();
				Timer timeRun = new Timer();
				timeRun.start();
				Judgmunt J_Munt = new Judgmunt(); 
				J_Munt.start();
			}
		});
		
		StartPopup.setLocationRelativeTo(null);
		StartPopup.setVisible(true);
		//--------시작 팝업 끝
		
		setBounds(0, 0, Pan_X, Pan_Y);
		setLayout(null);
		
		//--------타이틀바 영역 시작
		titleBar = new JPanel();
		titleBar.setBounds(0, 0, Pan_X, 30);
		getContentPane().add(titleBar);
		titleBar.setBackground(new Color(107,102,255,200));
		titleBar.setLayout(null);
		
//		restartBtn = new JButton("재시작");
//		restartBtn.setBounds(0, 0, 90, 30);
//		titleBar.add(restartBtn);
//		
//		restartBtn.addActionListener(new AbstractAction() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("재시작!!!");
//				Map_X = -1219; Map_Y = -1630;
//				map_lb.setLocation(Map_X,Map_Y);	
//			}
//		});
//		restartBtn.setFocusable(false);
		
		// fisnishPopup창에서의 재시작
//		restartBtnOnPopup = new JButton("다시 도전");
//		restartBtnOnPopup.addActionListener(new AbstractAction() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("다시 도전");
//				Map_X = -1219; Map_Y = -1630;
//				map_lb.setLocation(-1219,-1630);
//				gameState = false;
//				//timeRun.stop();
//			}
//		});
		// gameState상태를 다시 true로 바꿔줌
//		if (gameState == false) {
//			gameState=true;	
//		}
//		restartBtnOnPopup.setFocusable(false);
		
		// ------------프로그램 종료
		finishBtn = new JButton("프로그램 종료");
		finishBtn.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("프로그램 종료");
				gameState = false;
				System.exit(0);
			}
		});
		finishBtn.setFocusable(false);
		
		///성공시 프로그램 종료
		WinBtn = new JButton("성공");
		WinBtn.addActionListener(new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		
		Item_State = new JPanel();
		Item_State.setBounds(240, 0, 364, 30);
		Item_State.setBackground(new Color(178,204,255));
		titleBar.add(Item_State);
		Item_State.setLayout(null);
		
		//찬희형꺼 추가목
		
		////------------찬추
		
		Item_lb = new JLabel("Item :");
		Item_lb.setBounds(10, 0, 35, 30);
		Item_State.add(Item_lb);
		
		speed_lb = new JLabel("X ");
		speed_lb.setIcon(new ImageIcon("ff/MazeEscape_img (1)/Item/boot.png"));
		speed_lb.setBounds(70, 0, 80, 30);
		Item_State.add(speed_lb);
		
		key_lb = new JLabel("X ");
		key_lb.setIcon(new ImageIcon("ff/MazeEscape_img (1)/Item/key.png"));
		key_lb.setBounds(170, 0, 67, 30);
		Item_State.add(key_lb);
		
		Time_lb = new JLabel(">  " + Limit+"초 <");
		Time_lb.setIcon(new ImageIcon("ff/MazeEscape_img (1)/Item/SandTimer.png"));
		Time_lb.setBounds(270, 0, 123, 30);
		Item_State.add(Time_lb);
		//--------타이틀바 영역 끝
		
		//--------케릭터 영역 시작
		Player = new JPanel();
		Player.setBounds(player_X, player_Y, player_Ic_X,player_Ic_Y);
		Player.setBackground(new Color(255,0,0,0));
		Player.setOpaque(false);
		player_img = new JLabel(player_IC);
		Player.add(player_img);
		add(Player);
		
		//--------케릭터 영역 끝
	
		//--------맵 영역 시작
		Map = new JPanel();
		Map.setBounds(Map_X, Map_Y, MapSize_X, MapSize_Y);
		Map.setLayout(getLayout());
		
		Char_ax = new JPanel();
		Char_ax.setBackground(Color.RED);
		Char_ax.setBounds(1375+player_Ic_Y/4,1925-player_Ic_Y, 10, player_Ic_Y);
		System.out.println("ic_size :"+player_Ic_Y+","+Char_ax.getBounds().y+","+(Char_ax.getBounds().y+player_Ic_Y));
		Map.add(Char_ax);
		
		map_lb = new JLabel();
		map_lb.setIcon(new ImageIcon(Map_img[0]));
		map_lb.addMouseListener(this);
 		
		//--------지형지물 추가 영역 시작
		
		for (int i = 0; i < items_featrue.length; i++) {
			Map.add(new Img_arr(items_featrue[i][0],items_featrue[i][1],items_featrue[i][2]));
		}
		
		for (int i = 0; i < feature_ladder.length; i++) {
			Map.add(new Feature_lb(feature_ladder[i][0],feature_ladder[i][1],feature_ladder[i][2]));
		}
		for (int i = 0; i < feature_dcr.length; i++) {
			Map.add(new Feature_lb(feature_dcr[i][0],feature_dcr[i][1],feature_dcr[i][2]));
		}
		for (int i = 0; i < feature_Block.length; i++) {
			Map.add(new Feature_lb(feature_Block[i][0],feature_Block[i][1],feature_Block[i][2]));
		}
		
	
		
		Map.add(map_lb);
		add(Map);
		//--------지형지물 추가 영역 끝
		
		setVisible(true);
		setResizable(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Item2 tm2 = new Item2();
		tm2.start();
		
		addKeyListener(this);
	}
	
	////--------찬추
	class Item2 extends Thread{			//���� ������ �ð�
		@Override
		public void run() {
			
			while(true) {
				try {
					sleep(50);
					for(int i = 0; i<items_featrue.length; i++) {
						if((int)items_featrue[i][1]+Map.getY()>=230&&(int)items_featrue[i][1]+Map.getY()<=270) {
							System.out.println("나야");
						}
					}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}	
			
			
			//Dialog WinPopup = new JDialog();
           // WinPopup.setBounds(750, 450, 400, 100);
            //WinPopup.setLayout(new FlowLayout());
			//while(true) {
				//if(Map.getX()>-1114&&Map.getX()<-1039&&k==1) {
					//k = 0;
	              //  System.out.println("성공!");
	               // WinPopup.add(new JLabel("용사여 탈출을 축하드립니다. 빅토리아 아일랜드로 떠나보아요!"));
	              //  WinPopup.add(WinBtn);
						
	              //  WinPopup.setVisible(true);
			//	}
	          //  try {
	            //   sleep(10);
	          //
	           //    } catch(InterruptedException e) {
	          //     e.printStackTrace();
	            //}
	        // }
		}
	}
	////--------찬추
	class Judgmunt extends Thread{
			
			public void run() {
				try {
					while(gameState){
						sleep(100);
						LR_Break = false;
						UD_Break = false;
						for (int i = 0; i < feature_Block.length; i++) {
							ImageIcon Block_ic = new ImageIcon("MazeEscape_img (1)/Map/feature/"+(String)feature_Block[i][2]);
							if(	((int)feature_Block[i][1] <= Char_ax.getBounds().y+player_Ic_Y) &&
								((int)feature_Block[i][1]+5 >= Char_ax.getBounds().y+player_Ic_Y)&&
								((int)feature_Block[i][0]+5 < Char_ax.getBounds().x) &&
								((int)feature_Block[i][0]+Block_ic.getIconWidth()+5 >= Char_ax.getBounds().x+10)){
								LR_Break = true;
								break;
							}
						}
						for (int i = 0; i < feature_ladder.length; i++) {	
							if(((int)feature_ladder[i][0]+10 <= Char_ax.getBounds().x) &&
								((int)feature_ladder[i][0]+20 >= Char_ax.getBounds().x)) {
								System.out.println("UD_Break OFF");
								UD_Break = true;
								break;
							}
						}
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	
	int nowtime=0;
	class Timer extends Thread{			//게임 내부의 시간
		@Override
		public void run() {
			String fns = "";
			//닫기 팝업
			Dialog finishPopup = new JDialog();
			finishPopup.setBounds(750, 450, 400, 100);
			finishPopup.setLayout(new FlowLayout());
			while(gameState) {	
				Time_lb = new JLabel();
				for ( t = Limit; t >= 0; t--) {
//					System.out.println(i+"초");
					if(ddd==true) {
						t += AddTime;
					}
					ddd=false;
					
					Time_lb.setText((t)+"초");
					
					if (t==0) {
						fns = "끝";	
						System.out.println(fns);
						
						finishPopup.add(new JLabel("시간 초과! 프로그램 종료버튼을 눌러 종료해주세요"));
						finishPopup.setVisible(true);
						
						//finishPopup.add(restartBtnOnPopup);
						finishPopup.add(finishBtn);
						
						finishPopup.setVisible(true);
						
					}
					
					try {
						sleep(1000);
						if (fns=="끝") {
							break;
						}
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}	
			gameState = false;
			finishPopup.dispose();	
			
		}
	}
	

//--------------------------------------------------------------
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
//		System.out.println(key);
		switch(key){
		case 37:
			if(Map_X<=-4){
				Map_X +=Speed;
				Char_ax.setLocation(Char_ax.getBounds().x-5,Char_ax.getBounds().y) ;
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[2]));
			}
			break;
		case 39:
			if(Map_X>=-1215){
				Map_X -=Speed;
				Char_ax.setLocation(Char_ax.getBounds().x+5,Char_ax.getBounds().y);
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[3]));
				
			}
			break;
		case 38:
			if(Map_Y <=-95){
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[6]));
				Map_Y+=5;
				Char_ax.setLocation(Char_ax.getBounds().x+= Speed,Char_ax.getBounds().y-5);
			}
			break;
		case 40:
			//if(Map_Y==-1125||Map_Y==-615||Map_Y==-100) {
			//	Map_Y+=5;
			//} 
			if(Map_Y > -1625){
				player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[6]));
				Map_Y-=5;
				Char_ax.setLocation(Char_ax.getBounds().x+= Speed,Char_ax.getBounds().y+5);
				
			}
			break;
		}
		Map.setLocation(Map_X,Map_Y);
		
		System.out.println("map : "+Map.getX()+","+Map.getY()+"\npl :"+Player.getX()+","+Player.getY());
		System.out.println("mappan:");
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(player_img.getIcon().equals("ff/MazeEscape_img (1)/"+Player_img[3])){
			player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[1]));
		}else {
			player_img.setIcon(new ImageIcon("ff/MazeEscape_img (1)/"+Player_img[0]));
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Map 좌표 :"+e.getX()+","+e.getY());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
//--------------------------------------------------------------
	public static void main(String[] args) {
		
		new MazeEscape_ch();
	}
}
