package MP_MazeEscape;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class MazeEscape_01 extends JFrame implements KeyListener, MouseListener {
	JPanel topArea,T_L_Area,T_R_Area, map, Feature, player;
	JLabel player_img, map_img;
	ImageIcon map_IC = new ImageIcon("MazeEscape_img/Map/Dark_map.png");

	JLabel backLB;
	int Pan_X = 1000, Pan_Y = 800, Map_X = -1010, Map_Y = -1630;
	
	class FeaturePanel extends JPanel implements MouseListener{
		
		public FeaturePanel(int x, int y, String img) {
			ImageIcon ICon = new ImageIcon("MazeEscape_img/"+img);
			int IC_X=ICon.getIconWidth()+5,IC_Y=ICon.getIconHeight()+5;
			setBounds(x,y, 200, 200);

//			setOpaque(true);
			setLayout(null);
			
			backLB = new JLabel(ICon);
			backLB.setBounds(0,0, this.getWidth(),this.getHeight());
			backLB.setOpaque(true);
			add(backLB);
			
			addMouseListener(this);
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			System.out.println("map에서 좌표 :"+e.getX()+","+e.getY());
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	public MazeEscape_01(String Game_Name) {	//기본 배경 설정
		super(Game_Name);
		setBounds(10,10,Pan_X,Pan_Y);
		setLayout(null);

		topArea = new JPanel();
		topArea.setBounds(0, 0, Pan_X, 50);
		topArea.setLayout(new GridLayout(1,2));
		topArea.setBackground(Color.blue);
		topArea.add(T_L_Area = new JPanel());
		T_L_Area.setLayout(new FlowLayout(FlowLayout.LEFT,30,10));
		topArea.add(T_R_Area = new JPanel());
		T_R_Area.setLayout(new FlowLayout(FlowLayout.RIGHT));
		JButton restart = new JButton("재시작");
		JLabel time = new JLabel("00h00m00s");
		T_L_Area.add(restart);
		T_L_Area.add(time);
		T_L_Area.add(time);
		T_R_Area.add(time);
		
		add(topArea);
		
		map = new JPanel();
		map.setBounds(Map_X,Map_Y,2000,2400);
		setVisible(false);
		map.setLayout(null);
		map.add(new FeaturePanel(1458,1937,"Map/Base.png"));
		map.add(new FeaturePanel(1300,1929,"Map/feature/block/yellow_block.png"));
		add(map);
		
		Feature = new JPanel();//왜 안보이는가???
		Feature.setBounds(Map_X,Map_Y,2000,2400);
		map_img = new JLabel(new ImageIcon("fff/MazeEscape/Map/Dark_map.png"));
		Feature.add(map_img);
		Feature.setVisible(true);
		add(Feature);

		setVisible(true);
//		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addKeyListener(this);
		addMouseListener(this);
	}
	
	class Timer extends Thread{			//게임 내부의 시간
		@Override
		public void run() {
			// TODO Auto-generated method stub
			super.run();
		}
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
		//System.out.println(key);
		switch(key){
		case 37:
			Map_X+=5;
				
//			System.out.println("왼쪽");
			break;
		case 39:
			Map_X-=5;
			
			
//			System.out.println("오른쪽");
			break;
		case 38:
			Map_Y+=5;
			
//			System.out.println("위");
			break;
		case 40:
			Map_Y-=5;
			
//			System.out.println("아래");
			break;
		}
		map.setLocation(Map_X,Map_Y);
		Feature.setLocation(Map_X,Map_Y);
		System.out.println("map : "+Feature.getX()+","+Feature.getY());
		//"pl : "+player.getX()+","+player.getY()+"\n
		//box.setLocation(200, 100);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
//		player_img.setIcon(new ImageIcon(P_Images[0]));
	}
	
	public static void main(String[] args) {
		new MazeEscape_01("Potato MazeEscape");

	}
//--------------------------------------------------------------
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("프레임에서 좌표 :"+e.getX()+","+e.getY());
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
