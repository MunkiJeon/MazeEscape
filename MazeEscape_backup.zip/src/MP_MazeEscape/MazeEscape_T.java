package MP_MazeEscape;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MazeEscape_T {
	JPanel titleBar, Item_State, Player, Feature, Map;
	JLabel HP_lb, Item_lb,key_lb,speed_lb,heart_lb,timeLimit, player_img, map_lb, FT_LB;
	JButton restartBtn;

	int Pan_X = 800, Pan_Y = 600, 
		Map_X = -1014, Map_Y = -1545, MapSize_X = 2000,MapSize_Y = 2400;
	boolean gameState = false;
	
	String [] Player_img= {"Player/stop_L.gif","Player/stop_R.gif",
						"Player/walk_L.gif","Player/walk_R.gif",
						"Player/proneStab_L.gif","proneStab_R.gif",
						"Player/rope.gif","Player/dead.gif"};
	ImageIcon player_IC = new ImageIcon("MazeEscape_img/"+Player_img[0]);
	int player_Ic_X=player_IC.getIconWidth()+5,player_Ic_Y=player_IC.getIconHeight()+5,
		player_X = Pan_X/2-player_Ic_X, player_Y = Pan_Y/2-player_Ic_Y;
	
	String [] feature_img= {"Base.png",
	};
	
	String [] Map_img= {"MazeEscape_img/Map/Dark_map_00.png",
			};
	private JFrame GameBoard;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MazeEscape_T window = new MazeEscape_T();
					window.GameBoard.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MazeEscape_T() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		GameBoard = new JFrame();
		GameBoard.getContentPane().addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		GameBoard.setLocationRelativeTo(null);
		GameBoard.setBounds(0, 0, 1000, 800);
		GameBoard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GameBoard.getContentPane().setLayout(null);
		
		JPanel titleBar = new JPanel();
		titleBar.setBounds(0, 0, 1000, 30);
		GameBoard.getContentPane().add(titleBar);
		titleBar.setLayout(null);
		
		JButton restartBtn = new JButton("재시작");
		restartBtn.setBounds(0, 0, 90, 30);
		titleBar.add(restartBtn);
		
		JPanel Item_State = new JPanel();
		Item_State.setBounds(285, 0, 364, 30);
		titleBar.add(Item_State);
		Item_State.setLayout(null);
		
		JLabel HP_lb = new JLabel("HP :");
		HP_lb.setBounds(0, 0, 35, 30);
		Item_State.add(HP_lb);
		
		JLabel Item_lb = new JLabel("Item :");
		Item_lb.setBounds(130, 0, 35, 30);
		Item_State.add(Item_lb);
		
		JLabel key_lb = new JLabel("X n");
		key_lb.setIcon(new ImageIcon("E:\\USB_Java\\MazeEscape\\MazeEscape_img\\Item\\key.png"));
		key_lb.setBounds(285, 0, 67, 30);
		Item_State.add(key_lb);
		
		JLabel speed_lb = new JLabel("X n");
		speed_lb.setIcon(new ImageIcon("E:\\USB_Java\\MazeEscape\\MazeEscape_img\\Item\\boot.png"));
		speed_lb.setBounds(195, 0, 67, 30);
		Item_State.add(speed_lb);
		
		JLabel heart_lb = new JLabel("X n");
		heart_lb.setIcon(new ImageIcon("E:\\USB_Java\\MazeEscape\\MazeEscape_img\\Item\\heart.png"));
		heart_lb.setBounds(46, 0, 67, 30);
		Item_State.add(heart_lb);
		
		JLabel timeLimit = new JLabel("  -- s");
		timeLimit.setIcon(new ImageIcon("E:\\USB_Java\\MazeEscape\\MazeEscape_img\\Item\\SandTimer.png"));
		timeLimit.setBounds(865, 0, 123, 30);
		titleBar.add(timeLimit);
		//---------------------------------------------------------------
		Player = new JPanel(); // 케릭터
		Player.setBounds(player_X, player_Y, player_Ic_X,player_Ic_Y);
		Player.setOpaque(false);
		player_img = new JLabel(player_IC);
		Player.add(player_img);
		GameBoard.getContentPane().add(Player);
		
		Map = new JPanel(); // 맵 판넬
		Map.setBounds(50, 50, 484, 664);
		GameBoard.getContentPane().add(Map);
		Map.setLayout(null);
		
		Feature = new JPanel(); // 블럭 판넬
		Feature.setBounds(10, 10, 695, 229);
		Map.add(Feature);
//		Feature.setBackground(new Color(0,0,0,0));
		Feature.setBackground(new Color(0,0,0));
		Feature.setLayout(null);
		
		JLabel block_01 = new JLabel();	// 블럭
		block_01.setHorizontalAlignment(SwingConstants.CENTER);
		block_01.setIcon(new ImageIcon("MazeEscape_img/Map/feature/block/yellow_block2.png"));
		block_01.setBounds(50, 20, 100, 20);
		Feature.add(block_01);
		
		map_lb = new JLabel(); // 맵 이미지
		map_lb.setBounds(0, 0, 484, 664);
		Map.add(map_lb);
		map_lb.setIcon(new ImageIcon(Map_img[0]));
		map_lb.setHorizontalAlignment(SwingConstants.CENTER);
		
		GameBoard.setVisible(true);
		GameBoard.setResizable(false);
		GameBoard.setLocationRelativeTo(null);
	}
}
