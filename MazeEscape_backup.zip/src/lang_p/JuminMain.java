package lang_p;

public class JuminMain {

	public static void main(String[] args) {
		/*
		 시스템 (OS - window, MacOS, 안드로이드, ios, 리눅스, 유닉스 ) -> 클라우드 AWS
		 네트워크 (NAT, 브릿지, host only......) CCNA
		 개발 (응용 - 네이티브, 웹, 모바일
		      디바이스 - IOT, PLC, CNC.......,
		      data 분석 - 빅데이터, 머신러닝, AI
		      DB
		 )
		 보안
		 * */
		
		///만나이, 올해생일, 다가올 생일, 생일파티 DDay를 풀지 못했습니다.
		String jumin = "940209-1234567";

		char ch = 'a';
		System.out.println(ch);
		System.out.println((int)ch);
		
		ch = '0';
		System.out.println(ch);
		System.out.println((int)ch);
		
		ch = 100;
		System.out.println(ch);
		System.out.println((int)ch);
		
		
		int pos = jumin.charAt(7)-'0';
		System.out.println( "여남".charAt(pos%2) );
		System.out.println( "내외".charAt(pos/5)+"국인" );
		
		
		String title = "년월일";
		int [] birth = new int[title.length()];
		//0 -년, 1-월, 2- 일
		
		//String yy = jumin.substring(0, 2);
		//System.out.println(yy);
		
		
		//char [] arr = yy.toCharArray();
		//for (char c : yy.toCharArray()) {
		/*
		for (char c : jumin.substring(0, 2).toCharArray()) {
			birth[0] *= 10;
			birth[0] += c-'0';
		}
		
		for (char c : jumin.substring(2,4).toCharArray()) {
			birth[1] *= 10;
			birth[1] += c-'0';
		}
		for (char c : jumin.substring(4,6).toCharArray()) {
			birth[2] *= 10;
			birth[2] += c-'0';
		}*/
		
		for (int i = 0; i < birth.length; i++) {
			for (char c : jumin.substring(i*2,i*2+2).toCharArray()) {
				birth[i] *= 10;
				birth[i] += c-'0';
			}
		}
		
		//성별, 국적, 생년월일, 한국나이, 만나이, 올해생일, 다가올 생일, 생일파티 DDay를 출력하세요
		
		
		birth[0] += ((pos-1)	%4	/2	+19) *100;
		
		dayPPP("생년월일",birth);
		
		int [] now = {2022, 10,23}; 
		System.out.println(now[0]-birth[0]+1);
		
		int age = now[0]-birth[0];
		
		birth[0] = now[0];
		dayPPP("올해생일",birth);
		
		/*
		 
		 |----------------|----------|---------|------------|
		 1.1			지난생일       오늘      지나지않은생일   12.31
		 */
		
		int [] mm = {0,31,28,31,30,31,30,31,31,30,31,30,31};
		int dday = 0;
		//생일이 지나지 않은 걸 달이랑 일자 계산이 어려워요
		if(birth[1]>now[1] || (birth[1]==now[1] && birth[2]>now[2])) {
			age--;
			dday += mm[now[1]]-now[2];
			for (int i = now[1]+1; i < birth[1]; i++) {
				dday += mm[i];
			}
			dday += birth[2];
		}else {
			birth[0]++;
			dday += mm[now[1]]-now[2];
			
			for (int i = now[1]+1; i < mm.length; i++) {
				dday += mm[i];
			}
			for (int i = 1; i < birth[1]; i++) {
				dday += mm[i];
			}
			dday += birth[2];
		}
		
		System.out.println(age);
		dayPPP("다가올생일",birth);
		System.out.println(dday);
		
		
/*

 bit													byte
 								BCD			ASCII		EBCDIC
 1	2	3		4			5	6			7			8
 2	4	8		16			32	64			128			256
 ---------------------------------------------------------------
 0	00	000		0~9 (10)		A~Z 26		+특수문자		+부호(양수/음수)
 1	01	001						a~z 26
 	10	010						0~9 10
 	11	011						--------
 		100							62
 		101
 		110
 		111
 		
 		
 			-1	%4	/2	+19	*100
 1900	1	0	0	0	19	1900
 1900	2	1	1	0
 		----------------------------------------------
 2000	3	2	2	1	20	2000
 2000	4	3	3	1
 ---------------------------------------------------
 1900	5	4	0
 1900	6	5	1
 2000	7	6	2
 2000	8	7	3
 		
 		
 		
 * */		
		
		String ttt = "aBcd Efg HIJk lMn opQR";
		//"aBcd Efg HIJk lMn opQR" -> Abcd Efg Hijk Lmn Opqr  로 변경해 주세요
		//"lMn aBcd HIJk opQR  Efg" -> GFe rqPO Kjih DCbA NmL  로 변경해 주세요
		
		String res = "";
		for (String t : ttt.toLowerCase().split(" ")) {
			//res+=(char)(t.charAt(0)-('a'-'A'));
			res+=t.substring(0,1).toUpperCase()+t.substring(1)+" ";
			//System.out.println(t);
		}
		
		System.out.println(res.trim());
		
		
		res = "";
		ttt = "lMn aBcd HIJk opQR  Efg";
		int gap = 'a'-'A';
		for (int i = ttt.length()-1; i >=0; i--) {
			
		
			char c = ttt.charAt(i);
			
			if(c==' ') {
				res+=' ';
			}
			else if(c>='a') {
				res+=(char)(c-gap);
			}else {
				res+=(char)(c+gap);
			}
		}
		
		System.out.println(res);
		
	}
	
	static void dayPPP(String name,int [] arr) {
		String title = "년월일";
		System.out.print(name+":");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+""+title.charAt(i));
		}
		System.out.println();
	}
	

}
