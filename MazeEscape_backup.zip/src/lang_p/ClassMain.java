package lang_p;

class CC_A{
	int a =10;
	String b = "CC_A.b";
	
	void math_1() {
		System.out.println("CC_A math_1() 입니다");
		
	}
	void math_2() {
		System.out.println("CC_A math_2() 입니다");
		
	}
			
}
class CC_B{
	int a =10;
	String b = "CC_B.b";
	
	void math_1() {
		System.out.println("CC_B math_1() 입니다");
		
	}
	void math_2() {
		System.out.println("CC_B math_2() 입니다");
		
	}
			
}

public class ClassMain {

	public static void main(String[] args) throws Exception {
		CC_A a1 =new CC_A();
		
		System.out.println("a1:"+a1.a+","+a1.b);
		a1.math_1();
		a1.math_2();
		
		Class c1 = a1.getClass();//class는 기본적으로 GetClass를 갖고 있음
		System.out.println("c1:"+c1);
		System.out.println("c1:"+c1.getName());
		
		Class c2 =Class.forName("lang_p.CC_A"); //풀네임으로 적어야 애러안남
		
		Object a2 = c1.newInstance();
		Object a3 = c2.newInstance();
		CC_A a4 = (CC_A)c1.newInstance();
		CC_A a5 = (CC_A)c2.newInstance();
		
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
		System.out.println(a5);
		
		a4.math_1();
		a5.math_1();
		
		String ttt = "lang_p.CC_A";
		
		CC_A a6 = (CC_A)Class.forName(ttt).newInstance();
		System.out.println(a6);
		
		a6.math_1();
		
		CC_B b7 = (CC_B)Class.forName(ttt).newInstance();
		
		
	}

}
