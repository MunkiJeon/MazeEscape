package lang_p;

class ObjShape{
	
	String kind;
	int area, border;

	public ObjShape(String kind) {
		super();
		this.kind = kind;
		area = 0;
		border = 0;
	}

	public ObjShape(int r) {//원
		
		kind = "원";
		double pi = 3.141592;
		area = (int)(r * r * pi);
		border = (int)(r * 2 * pi);
	}
	
	public ObjShape(int w, int h) {//직사각형
		
		kind = "직사각형";
		
		area = w * h;
		border = (w + h) * 2;
	}
	
	public ObjShape(int w, int h, int a) {//직각삼각형
		
		kind = "직각삼각형";
		
		area = w * h / 2;
		border = w + h + a;
	}

	@Override
	public String toString() {
		return kind + "\t" + area + ", " + border;
	}

	void calc(ObjShape [] shs) {
		for (ObjShape os : shs) {
			//System.out.println(os);
			if(equals(os)) {
				area += os.area;
				border += os.border;
			}
		}
		System.out.println("결과 -> "+this);
	}
	
	public boolean equals(Object oo) {
		ObjShape you = (ObjShape)oo;
		return kind.equals(you.kind);
	}
}

public class ObjShapeMain {

	public static void main(String[] args) {
		ObjShape [] shs = {
				new ObjShape(5),
				new ObjShape(5,6),
				new ObjShape(5,6,8),
				new ObjShape(7,10),
				new ObjShape(8),
				new ObjShape(9),
				new ObjShape(9,4,12)
		};
		
	
		ObjShape [] res = {
				new ObjShape("원"),
				new ObjShape("직사각형"),
				new ObjShape("직각삼각형")
		};
		
		for (ObjShape os : res) {
			os.calc(shs);
		}

	}

}
