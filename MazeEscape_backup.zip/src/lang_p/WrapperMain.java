package lang_p;

import java.util.Arrays;

public class WrapperMain {

	public static void main(String[] args) {
		int i = new Integer(1234);
		
		System.out.println(i);
		
		Integer i2 = 5678;

		System.out.println(i2);
		
		//i = null;
		i2 = null;
		//i = "1357";
		//i2 = "1357";
		i2 =  new Integer("1357");
		System.out.println(i2+100);
		
		//i2 =  new Integer("천오백삼십칠");  치환할수 없는 문자열 에러발생
		i = Integer.parseInt("2468");
		System.out.println(i);
		
		//i = Integer.parseInt("이천사백육십팔");
		byte b = Byte.parseByte("127");
		System.out.println(b);
		
		short sh = Short.parseShort("127");
		System.out.println(sh);
		
		Long lo = Long.parseLong("456789");
		System.out.println(lo);
		
		double d = Double.parseDouble("123.456");
		System.out.println(d);
		
		float f = Float.parseFloat("123.789");
		System.out.println(f);
		
		boolean bo = Boolean.parseBoolean("true");
		System.out.println(bo);
		
		
		System.out.println("2진수:"+Integer.toBinaryString(10));
		System.out.println("8진수:"+Integer.toOctalString(10));
		System.out.println("16진수:"+Integer.toHexString(10));
		
		
		//사진 파일을 확인하세요 ex) 영업_홍길동_20110823.jpg
		 
        //부서명, 이름 출력, 입사일
		
		String sawon = "영업_홍길동_20110823.jpg";
		String [] arr = sawon.split("_");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		int [] reg = {
				Integer.parseInt(arr[2].substring(0, 4)),
				Integer.parseInt(arr[2].substring(4,6)),
				Integer.parseInt(arr[2].substring(6,8)),
		};
		
		System.out.println(Arrays.toString(reg));
        
	}

}
