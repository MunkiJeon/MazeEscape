package oops_p;

public class UearExceptionMain {

	public static void main(String[] args) {
		try {
			System.out.println("try1");

//			Exception ex =new Exception("에러다 에러!!");
			
			throw new Exception("니가 가라 하와이");
//			System.out.println("try2");
//			throw ex;
//			System.out.println("try3");
		} catch (Exception e) {
			System.out.println("catch : "+e.getMessage());

		}

	}

}
