package oops_p;

import java.util.Scanner;

public class UserLoginMain {
/*

5명의 정보로 로그인을 구현하세요

로그인 성공시 이름으로 출력하세요

aa, 1111 = 이효리

bb, 2222 = 삼효리

cc, 3333 = 사효리

dd, 4444 = 오효리

ee, 5555 = 육효리

 */
	public static void main(String[] args) {
		String pid = "aaa", ppw = "1234";
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			
			try {
				
				System.out.print("어른디:");
				String id = sc.next();
				
				if(!id.equals(pid)) {
					throw new Exception("id 에러"); //컨티뉴 기능을 해버림
				}
				
				System.out.print("아뭐:");
				String pw = sc.next();
				
				if(!id.equals(ppw)) {
					throw new Exception("pw 에러"); //컨티뉴 기능을 해버림
				}
				
				break;
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			
		}
		
		System.out.println("로그인 성공");

	}

}
