package oops_p;

class ReThrow{
	void math_1() throws Exception {
		System.out.println("math_1() 지작");
		math_2();
		System.out.println("math_1() 끝");
	}
	void math_2() throws Exception {
		System.out.println("\tmath_2() 지작");
		try {
			math_3();
		} catch (Exception e) {
			System.out.println("m2 catch :"+e.getMessage());
			throw e;
		}
		
		System.out.println("\tmath_2() 끝");
	}
	void math_3() throws Exception{
		System.out.println("\t\tmath_3() 지작");
		try {
			throw new Exception("m3 에러");
		} catch (Exception e) {
			System.out.println("m3 catch :"+e.getMessage());
			throw e;
		}
//		System.out.println("\t\tmath_3() 끝");
	}
}

public class RetrowMain {
	public static void main(String[] args) throws Exception {
		ReThrow rt = new ReThrow();
		try {
			rt.math_1();
		} catch (Exception e) {
			System.out.println("Main catch :"+e.getMessage());
			throw e;
		}
	}
}
