package swing_p;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.LinkedHashMap;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class MousePostItMain extends JFrame implements MouseMotionListener,MouseListener {

	@Override
	public void mouseDragged(MouseEvent e) {

		e.getComponent().setLocation(e.getComponent().getX()+e.getX()/2,e.getComponent().getY()+e.getY()/2);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("move:"+e.getX()+","+e.getY());
	}
	Component aa;
	JPanel pp;
	ImageIcon icon;
	ImageIcon picon;
	JLabel backLB;
	
	LinkedHashMap<JPanel,JLabel> postIt_key = new LinkedHashMap<JPanel, JLabel>();
	
	String [] Images= {"fff/post2.png","fff/A_1.jpg","fff/A_2.jpg",
						"fff/A_3.jpg","fff/A_4.jpg"};
	
	int Images_i =(int)(Math.random()*Images.length);
	LinkedHashMap<JPanel,JLabel> [] pos_arr;
	
	public MousePostItMain() {
		super("마우스포th으트잇");
		setBounds(50, 50, 900, 600);
		setLayout(null);
		
		for (int i = 0; i <= 7; i++) {
			pp = new JPanel();
			pp.setBounds(50, 50, 170,170);
			pp.setLayout(null);
			
			JTextArea area = new JTextArea("포스트잇 1");
			area.setBounds(50, 50, 20,200);
			area.setOpaque(false);
			pp.add(area);
			
			icon =new ImageIcon("fff/post.png");
			backLB = new JLabel(icon);
			backLB.setBounds(0, 0, 170,170);
			pp.add(backLB);
			postIt_key.put(pp, backLB);
			
			add(pp);

			pp.addMouseMotionListener(this);
			pp.addMouseListener(this);
		}

		setResizable(false);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		

	}

	public static void main(String[] args) {
		new MousePostItMain();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
	
		System.out.println(e.getPoint()+",\n"+e.getSource()+",\n"+e.getID());
		Images_i =(int)(Math.random()*Images.length);
		picon =new ImageIcon(Images[Images_i]);
		backLB.setIcon(picon);
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		backLB.setIcon(icon);
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
