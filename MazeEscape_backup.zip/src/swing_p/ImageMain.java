package swing_p;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JFrame;

public class ImageMain extends JFrame {
	
	Image img, img1, img2, img3;
	Graphics gg, gg1, gg2, gg3; //도화지에 그릴 팬
	//paint Graphics 
	
	public ImageMain() {
		// TODO Auto-generated constructor stub
		super("Image");
		setBounds(50,50,800,600);
		
		
	
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		//이미지 생성 : GUI 컨테이너 급에서 createImage 로 생성
		img = createImage(200, 200);
		img1 = createImage(200, 200);
		img2 = createImage(200, 200);
		img3 = createImage(200, 200);
		
		// 이미지에 그릴 도구 가져오기
		// 화면을 그리고 나서 가져올수 있다  --> setVisible(true); 실행후에 처리해야함
		gg = img.getGraphics();
		gg1 = img1.getGraphics();
		gg2 = img2.getGraphics();
		gg3 = img3.getGraphics();

	}
	
	public void paint(Graphics g) { //모든 그리는 항목들은 페인트에서 해야함 
		super.paint(g);
		//도화지를 만들어 붙이는 작업
		gg.drawString("송지은 만세",50, 50);
		
		gg1.setColor(Color.blue);
		gg1.fillOval(30,30,100,100);
		
		gg2.setColor(Color.red);
		gg2.fillRect(20, 20, 80, 80);
		
		gg3.fillPolygon(new int[] {20,80,140},new int[] {90,0,90},3);
		
		g.drawImage(img,0,0,this);//this 의 위치 JFrame ->
		g.drawImage(img1,200,200,this);
		g.drawImage(img2,400,400,this);
		g.drawImage(img3,600,200,this);
		
		
//		g.drawI;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ImageMain();
	}

}
