package swing_p;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MouseBannerMain2 extends JFrame implements MouseListener, MouseMotionListener {

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		lastY = e.getY();

	}
	
	int curr, dst;

	@Override
	public void mouseReleased(MouseEvent e) {
		String arow = "->";
		if(e.getY()<lastY) {
			arow = "<-";
		}
		System.out.println(arow+":"+lastY+":"+e.getY());
		System.out.println(imgs.getY()+":"+dst);
		if(!moving) {
			int dir = 200;
			curr = 2;
			
			if(lastY<e.getY()) {
				if(imgs.getY()!=0)
				{
					dir=+150;
					curr=+2;
					dst = imgs.getY()+dir;
				}
			}
				
			if(lastY>e.getY()) {
				if(imgs.getY()!=-450)
				{
					dir=-150;
					curr=-2;
					dst = imgs.getY()+dir;
				}
			}	
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
	
	JPanel imgs;
	
	int lastY;
	
	public MouseBannerMain2() {
		super("마우스배너");
		setBounds(50, 50, 600, 500);
		setLayout(null);
		
		JPanel outer = new JPanel();
		outer.setBounds(200,150,200,150);
		outer.setLayout(null);
		
		outer.setBackground(Color.pink);
		add(outer);
		
		imgs =  new JPanel();
		imgs.setBounds(0,0,200,600);
		imgs.setLayout(new GridLayout(4,1));
		//imgs.setBackground(Color.YELLOW);
		outer.add(imgs);
		
		for (int i = 1; i <= 4; i++) {
			JLabel lb = new JLabel(new ImageIcon("fff/A_"+i+".jpg"));
			imgs.add(lb);
		}
		
		setResizable(false);
		setVisible(true);
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		addMouseListener(this);
		//addMouseMotionListener(this);
		
		new Timer().start();
	}
	
	boolean moving;
	
	class Timer extends Thread{
		@Override
		public void run() {
			while(true) {
				try {
					
					sleep(10);
					
					if(moving = dst!=imgs.getY()) {
						
						imgs.setLocation(0,imgs.getY()+curr);
					}
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MouseBannerMain2();
	}
	/*
	 1. 맨끝, 처음 일경우 더이상 움직이지 않게 해주세요
	 2. 세로방향으로 배너가 움직이게 새로 만들어 주세요
	 3. 무한으로 돌게 해주세요
	 * */
}
