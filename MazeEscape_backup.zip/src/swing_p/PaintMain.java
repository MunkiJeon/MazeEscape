package swing_p;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class PaintMain extends JFrame implements MouseListener{
	
	public PaintMain() {
		super("paint");
		System.out.println("생성자다!!!");
		
		setBounds(50, 50, 900, 600);
		setLayout(null);
//		setResizable(false);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	@Override
	public void paint(Graphics g) {
		super.paint(g); // 화면을 새로 그린다 배경을 다시 그림
		//화면 갱신시 자동호출
		//화면 갱신 : 화면 크기 변경(최대화 포함)
		System.out.println("print() 실행");
		g.setColor(Color.blue);
		g.setFont(new Font("휴먼편지체", Font.ITALIC,30));
		g.drawString("오점무??", 50,90);
		
		g.setColor(Color.red);
		g.fillRect(50, 120, 200, 100);
		
		g.setColor(Color.GREEN);
		g.drawRect(100, 120, 200, 100);
		
		g.setColor(Color.GREEN);
		g.fillOval(50, 250, 200, 100);
		
		g.setColor(Color.red);
		g.drawOval(100, 250, 200, 100);
		
		g.setColor(Color.BLACK);
		g.drawLine(120, 250, 300, 100);
		
		g.drawRoundRect(50, 370, 200, 100, 90, 30);
		
		g.drawArc(400, 50, 100, 100,90,90);
		
		g.setColor(Color.blue);
		g.fillArc(600, 50, 100, 100, 45,90);
		
		
		g.fillPolygon(
				new int[]{600,700,800,500},
				new int[]{400,370,530,500},
				4);
		g.setColor(Color.GREEN);

		g.fillPolygon(
				new int[] {600,700,800,500},
				new int[] {400,370,530,500},
				4
				);
		
		g.setColor(Color.green);
		g.drawPolygon(
				new int[] {500,600,700,400},
				new int[] {400,370,530,500},
				4
				);
		
		g.drawPolyline(
				new int[] {700,800,900,600},
				new int[] {400,370,530,500},
				4
				);
		
		g.setColor(Color.RED);
		g.drawPolyline(
				new int[] {600,700,800,500,600},
				new int[] {200,170,330,300,200},
				5
				);
		
		g.setColor(Color.black);
		
		g.drawPolygon(
				new int[] {314,358,432,479,445,419,386,360,347},
				new int[] {235,223,215,288,354,372,373,359,302},
				9
				);
		
		addMouseListener(this);
	}
	public static void main(String[] args) {
		new PaintMain();

	}
	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println(e.getX()+","+e.getY());
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
