package swing_p;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

import javax.swing.JFrame;

public class ImageResizeMain extends JFrame implements MouseListener {
	
	Image img1, img2, img3;
	
	public ImageResizeMain() {
		// TODO Auto-generated constructor stub
		super("이미지 사진");
		setBounds(50,50,1200,720);
		Toolkit kit = Toolkit.getDefaultToolkit();
		
		img1 = kit.getImage("fff/bordshark.jpg");
		img2 = img1.getScaledInstance(270, 480,Image.SCALE_SMOOTH);
		img3 = img1.getScaledInstance(270, 480,Image.SCALE_SMOOTH);
		
		File f =new File("fff/bordshark.jpg");
		System.out.println(f.exists()?"있음":"없음");
		
		setVisible(true);
		setResizable(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		addMouseListener(this);
	}
	@Override
	public void print(Graphics g) {
		// TODO Auto-generated method stub
		if (img1==null) {
			return;
		}
		super.print(g);
		g.drawImage(img1,100,100,this);
		g.drawImage(img2,300,100,this);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ImageResizeMain();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println(e.getX()+","+e.getY());
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
