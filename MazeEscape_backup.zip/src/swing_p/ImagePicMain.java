package swing_p;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class ImagePicMain extends JFrame implements MouseListener {
	
	Image img1, img2, img3, img4, img5;
	
	public ImagePicMain() {
		// TODO Auto-generated constructor stub
		super("이미지 사진");
		setBounds(50,50,1200,720);
		
		Toolkit kit = Toolkit.getDefaultToolkit();
		img1 =kit.getImage("fff/A_1.jpg");
		img2 =kit.getImage("fff/A_2.jpg");
		img3 =kit.getImage("fff/A_3.jpg");
		img4 =kit.getImage("fff/A_4.jpg");
		img5 =kit.getImage("fff/D_shark.png");
		
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		addMouseListener(this);
	}
	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		g.drawImage(img5,-1, -1,this.getWidth(),this.getHeight(),this);
		
		//매개변수가  6개인 경우 -> 원본을 잘라서 그려지는 위치를 지정하여 그려짐
		g.drawImage(img1,
				5, 5,//그려지는 시작위치
				400,300,// 크기가 아닌 끝나는 위치 => 시작보다 작은면 반전됨 
				//원본 위치
				0,50,//원본의 시작위치
				750,737,//원본의 끝 위치
				this);
		//매개변수가  6개인 경우 -> 원본은 전체가 그려지는 위치에 지정하여 그려짐
		g.drawImage(img2,
				9,458, //그려지는 시작위치
				375,250, //그려지는 크기
				this);
		//그려지는 시작위치만 지정하고 원본의 크기대로 그려지는 위치에 그려짐
		//g.drawImage(img2,20, 20,this);
		g.drawImage(img3,831,31,200,180,this);
		g.drawImage(img4,781,454,200,180,this);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ImagePicMain();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println(e.getX()+","+e.getY());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
