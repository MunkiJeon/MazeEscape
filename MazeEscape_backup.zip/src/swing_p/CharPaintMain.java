package swing_p;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class CharPaintMain extends JFrame implements MouseMotionListener, ActionListener {
	int P_x = -100 ,P_y = -100, size = 20;
	boolean first = true;
	String ttt;
	Color cc = Color.black;
	Color [] col = {Color.BLACK,Color.RED,Color.ORANGE,Color.YELLOW,Color.GREEN,Color.MAGENTA,Color.BLUE,Color.CYAN};
	
	public CharPaintMain() {
		
		System.out.println("생성자"+MouseEvent.BUTTON1_DOWN_MASK);
		System.out.println("생성자"+MouseEvent.BUTTON2_DOWN_MASK);
		System.out.println("생성자"+MouseEvent.BUTTON3_DOWN_MASK);
		
		setBounds(50, 50, 900, 600);
		System.out.println("생성자");
		setLayout(null);	
		getContentPane().setBackground(Color.black);
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
//		JPanel pallet = new JPanel();
//		
//		pallet.setBounds(0,0,900,100);
//		pallet.setLayout(new GridLayout());
//		for (int i = 0; i < col.length; i++) {
//			JLabel lb = new JLabel();
//			lb.setBackground(col[i]);
//			lb.setOpaque(true);
//			pallet.add(lb);
//		}
//		add(pallet);
		
		Color [] ccs = {Color.red, Color.orange, Color.yellow,
				Color.green, Color.blue, Color.pink,
				Color.black,Color.white
		};
		
		for (int i = 0; i < ccs.length; i++) {
			JButton btn = new JButton();
			btn.setBounds(0, 50*i, 50,50);
			btn.setBackground(ccs[i]);
			btn.addActionListener(this);

			add(btn);
		}
		
		JSlider jb = new JSlider(JSlider.HORIZONTAL, 5,80, 20);
		jb.setBounds(50, 350, 200,100);
		add(jb);
		
		jb.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				
				JSlider jjj = (JSlider)e.getSource();
				System.out.println(jjj.getValue());
				
				size = jjj.getValue();
			}
		});
		
	}
	
	
	
	@Override
	public void paint(Graphics g) {
		if(first) {
			g.setColor(Color.white);
			g.fillRect(100, 0, 550, 350);
			
			
		}
			g.setFont(new Font("휴먼편지체", Font.PLAIN, size));
			g.setColor(cc);
			g.drawString(ttt, P_x, P_y );
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		
		//System.out.println(e.getModifiersEx());
		//마우스 왼쪽버튼을 드래그 했다면 
		if(e.getModifiersEx()==MouseEvent.BUTTON1_DOWN_MASK) {
			ttt = "●";
		}else {
			ttt = "◇";
		}
		
		
		first = false;
		// TODO Auto-generated method stub
		//System.out.println("dragged"+e.getX()+","+e.getY());
		if(e.getX()>=100 && e.getY()<=350) {
			P_x = e.getX();
			P_y = e.getY();
			repaint();  //화면 다시 그리기
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		new CharPaintMain();
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton nowBtn = (JButton)e.getSource();
		//getSource() --> Object 형태로 리턴 : 이벤트소스객체를 받아옴
		//System.out.println("눌렀다"+nowBtn.getBackground());
		cc = nowBtn.getBackground();
	}
}
