package util_p;

import java.util.Scanner;
import java.util.regex.Pattern;

public class RegexMain {

	public static void main(String[] args) {
		System.out.println(Pattern.matches("장", "장동건"));
		System.out.println(Pattern.matches("장.*", "장동건"));
		System.out.println(Pattern.matches("장.*", "장혁"));
		System.out.println(Pattern.matches("장.*", "최장군"));
		
		String [] mmArr= {"장동건","건","장서건","장혁","장남건","장3","장빈건",
                "장","장군","최장군","박장군","장군님","장장장장장장장","장장","고추장",
                "미란다커","키커","쌍피","계피","원두커피장군",
                "장장장","김앤장이다","현빈","원빈","미스터빈","커피빈","커피","원두커피","장희빈",
                "ㄱㄴㄷ","ㄱㄹㄴ","ㅐㅓㅣㅔㅐ","ㅐㅔㅓㅐㅑㅓ","ㄱㅓㅔㅔㅔㄹㄴ",
                "하하하","하호허","팉툍하","하학","하햐","가긱공국","짱쩡맨","쑥ㄴ밬","샹쏑쑗",
                "다","공석호","김희애",
                "나야비","나비야","농ㅂ왕창","장ㄴ비용솽",
                "너탈비털아붕니","너비아니","헤르너비아샹쵕",
                "123-456","1234-5678",
                "1","14","33","333","336","999",
                "1234-5678-9012","123-5678-9012","12-5678-9012","12-568-9012",
                "123-678-9012","123-567833-9012","12-58-9012","1a",
                "abc","abc_def","1234","9846","ab_1234","ab1234",
                "aaa@aaa.aaa","aaaaaa.aaa@","aaa12aaa_aaa@",
                "ab56","AABB","aBCd","1","3","1234abc@aaa.aaa",
                "1234abc@aaa.a","1a2b","a12",
                "^","^^","12^34abc@aaa.aaa","1a2b^","^a12","123456.^",
                "\\^","^\\^",".^","\\^^",
                "1234abc@aaa.aa.va","1234abc@a.aa.a.a.va","940709-1901111"};
		
		String [] ppArr = {"장","장.","장.*",".*장.*",".장.","장*",".*빈",
				".*빈건",".*(빈건)",".*(빈|건)",".*빈|건",".*[빈건]",/*=*/".*[빈|건]",
				".*(장군|커피)",".*[장군|커피]",
				"\\d","\\d*","\\D","\\D*","\\w","\\w*","\\W","\\W*",
				"[0-9]","[0-9]*","[a-z]*","[A-Z]*","[A-Za-z0-9]*","[A-Za-z0-9._-]*",
				"[A-Za-z0-9]*@[A-Za-z0-9.]*",
				".{4}",".{3,}",".{3,5}",//".{,7}"
				"[0-9]{2,3}-[0-9]{3,4}-[0-9]{4}","[0-9]{6}-[0-9]{7}",
				"[^0-9]*","[0-9^]*","\\^*","[^^]*",
				"[ㄱ-ㅎ]*","[ㅏ-ㅣ]*","[가-힣]*","[ㄱ-ㅎㅏ-ㅣ가-힣]*",
				"[가-깋ㄱ]*",".*[나-닣ㄴ][바-빟ㅂ][아-잏ㅇ].*",
				".*[가-닣][나-][아-잏ㅇ].*"//강남구
				,"[369]","[369]{2}","[369]{3}"
				};
		
		for (String pp : ppArr) {
            System.out.print(pp+":");
            for(String mm : mmArr) {
            	if(Pattern.matches(pp, mm)) {
            	System.out.print(mm+",");
            	}
            }
            
            System.out.println();
		}
		
		/*이메일을 검사하세요
		 * ex) abcd@aaaaa.bb.cc
		 * 
		 * @가 한개 --->@ 기준으로 아이디와 도메인이 분리
		 * 아이디는 영문 숫자로만 구성 5글자 이상
		 * 도메인은 .의 겟수가 1 or 2 이여야 하며
		 * 1개 기관명 기관종류		
		 * 2개 기관명 기관종류 국가	
		 * 단, 기관종류, 국가명은 특정 값은 없는걸로 (인지 영문 소문자이면 가능)
		 * 기관명은 영문, 숫자가능,4자 이상
		*/

		System.out.println("-------------======================--------------");
//		Scanner sc = new Scanner(System.in);
		
		String [] e_Arr = {
				"a0s0e0@naver.com","q9q9q9@citizen.seoul.kr","dd88@daum.net",
				순서"2022dd@daum.net","aaaa@narasarang.or.kr"
		};
	
		String[] ins = {"[A-Za-z0-9.{5,}]*@[A-Za-z0-9.{4,}]*[.]([a-z]{3}|[a-z]{2}[.][a-z]{2})"};
		
		System.out.println("아이디 @ 기관명 기관종류 국가");
		for (String ip : ins) {
            System.out.print(ip+":\n");
            for(String ep : e_Arr) {
            	if(Pattern.matches(ip, ep)) {
            	System.out.print(ep+"\n");
            	}
            }
            System.out.println();
		}	
	}
}
