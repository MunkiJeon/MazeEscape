package collection_p;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;


class TMStud implements Comparable<TMStud>{
	String gender, name; 
	int ban, tot, avg, rank;
	int [] jum;
	public TMStud(int ban, String gender, String name, int kor, int eng, int mat) {
		super();
		this.ban = ban;
		this.gender = gender;
		this.name = name;
		jum = new int[] {kor, eng, mat};
		calc();
	}
	
	private void calc() {
		tot = 0;
		for (int i : jum) {
			tot += i;
		}
		avg = tot/jum.length;
	}

	@Override
	public int compareTo(TMStud you) {
		int res = you.avg - avg;
		if(res==0) {
			res = 1;
		}
		return res;
	}

	@Override
	public String toString() {
		return ban + "\t" + gender + "\t" + name + "\t" + Arrays.toString(jum)
				+ "\t" + tot + "\t" + avg + "\t" + rank;
	}
	
	void rankCalc(Set<TMStud> set) {
		rank = 1;
		for (TMStud you : set) {
			if(you.avg > avg) {
				rank++;
			}
		}
	}
}

public class TreeMapExamMain {

	public static void main(String[] args) {
		TMStud [] studs = {
				
				new TMStud(5, "여", "투빈", 67,78,82),
				new TMStud(1, "남", "원빈", 77,88,92),
				new TMStud(3, "남", "김우빈", 57,48,32),
				new TMStud(3, "여", "현빈", 7,18,22),
				new TMStud(2, "아저씨", "골빈", 17,28,32),
				new TMStud(1, "여", "장희빈", 27,58,82),
				new TMStud(1, "아저씨", "젤리빈", 17,48,72),
				new TMStud(5, "여", "커피빈", 37,68,92),
				new TMStud(1, "남", "텅빈", 17,48,62),
				new TMStud(3, "여", "터빈", 77,78,72),
				new TMStud(3, "남", "미스터빈", 87,88,82),
				new TMStud(2, "여", "미스빈", 97,98,92),
				new TMStud(2, "남", "독일빈", 87,88,72),
				new TMStud(1, "여", "빈", 57,68,62)
		};
		
		TreeMap<Integer, TreeMap<String, TreeSet<TMStud>>> banMap = new TreeMap();

		for (TMStud st : studs) {
			
			if(!banMap.containsKey(st.ban)) {
				banMap.put(st.ban,  new TreeMap());
			}
			TreeMap<String, TreeSet<TMStud>> tm = banMap.get(st.ban);
			
			if(!tm.containsKey(st.gender)) {
				tm.put(st.gender,  new TreeSet());
			}	
			tm.get(st.gender).add(st);
			
		}
		
		for (Map.Entry<Integer, TreeMap<String, TreeSet<TMStud>>> bbMet : banMap.entrySet()) {
			
			System.out.println("[[["+bbMet.getKey()+"반]]]");
			
			for (Map.Entry<String, TreeSet<TMStud>> met : bbMet.getValue().entrySet()) {
			
				System.out.println("\t"+met.getKey()+">>>");
					
				for (TMStud st  : met.getValue()) {
			
					st.rankCalc(met.getValue());
					System.out.println(st);
				}
			}
		}
	}
}
