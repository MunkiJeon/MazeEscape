package util_p;

import java.util.Calendar;

public class DiaryMain {

	public static void main(String[] args) {
		
		Calendar today = Calendar.getInstance();
		
		int last = today.getActualMaximum(Calendar.DATE);
		
		today.set(Calendar.DATE, 1);
		int first = today.get(Calendar.DAY_OF_WEEK);
		
		//System.out.println(first);
		
		for (int i = 1; i < first; i++) {
			System.out.print("\t");
		}
		
		for (int i = 1; i <=last; i++) {
			today.set(Calendar.DATE, i);
			int ww = today.get(Calendar.DAY_OF_WEEK);
			
			System.out.print(i+"\t");
			if(ww==7) {
				System.out.println();
			}
		}
	}

}
