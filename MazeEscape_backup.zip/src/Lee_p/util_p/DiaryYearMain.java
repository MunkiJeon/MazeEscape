package util_p;

import java.util.Calendar;

public class DiaryYearMain {

	public static void main(String[] args) {
		/*
		 이해 : 3가지 작업
		 1. 설명하는 내용을 이해한다.
		 2. 구현(코딩), 검증
		 3. 정리 (기록) 
		 * 
		 * 
		 * 1. 이번달 끝 			         getActualMaximum(Calendar.DATE)
		 * 2. 각 날짜의 요일 토요일 -> 줄바꿈    get(Calendar.DAY_OF_WEEK) == 7
		 * 3. 달의 첫째날 요일만큼 빈칸 형성     for : 1-> get(Calendar.DAY_OF_WEEK)
		 * 
		 * 
		 * 
		 * */
		
		Calendar today = Calendar.getInstance();
		
		int yy = 2021;
		
		for (int mm = 1; mm <=12; mm++) {
			
		
			System.out.println("\n\n\n"+mm+"월\n");
			today.set(yy, mm-1,1);
			
			int first = today.get(Calendar.DAY_OF_WEEK);
				
			int last = today.getActualMaximum(Calendar.DATE);
			
			for (int i = 1; i < first; i++) {
				System.out.print("\t");
			}
			
			for (int i = 1; i <= last; i++) {
				
				today.set(Calendar.DATE, i);
				System.out.print(i+"\t");
				if(today.get(Calendar.DAY_OF_WEEK)==7) {
					System.out.println();
				}	
			}
		}
		
		
		/*
		 * 1   2    3  ....
		 * 1주
		 * 2주
		 * 3주
		 * 4주
		 * 5주
		 * 6주
		 * 
		 * 
		 * for(  주  : 1->6 ){
		 *     for( 달 : 0 -> 11){
		 *     
		 *     }
		 * }
		 * 
		 * 주?
		 * 
		 * 
		 * */
		
		
		
		String [][] weeks = new String[12][7];
		String [][] spec = new String[12][7];
		
		/*
		for (int m = 0; m < weeks.length; m++) {
			String [] mm = weeks[m];
			for (int i = 0; i < mm.length; i++) {
				mm[i] = "";
			}
			today.set(yy,m,1);
			int first = today.get(Calendar.DAY_OF_WEEK);
			System.out.println(first);
			for (int i = 1; i < first; i++) {
				mm[1] += "\t";
			}
		}*/
		
		today.set(yy,1-1,0);
		for (int i = 1; i <=today.getActualMaximum(Calendar.DAY_OF_YEAR); i++) {
			today.add(Calendar.DATE,1);
			//System.out.println(i+","+today.get(Calendar.DATE)+","+today.get(Calendar.WEEK_OF_MONTH)+","+today.get(Calendar.MONTH));
			
			//월요일 null 제거
			if(today.get(Calendar.DAY_OF_WEEK)==1) {
				weeks[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]="";
				spec[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]="";
			}
			
			// 1일 빈칸
			if(today.get(Calendar.DATE)==1) {
				weeks[today.get(Calendar.MONTH)][0]="\t\t\t"+(today.get(Calendar.MONTH)+1)+"월\t\t\t\t";
				weeks[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]="";
				
				for (int f = 1; f <today.get(Calendar.DAY_OF_WEEK); f++) {
					weeks[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+="\t";
				}
				//////////////////
				
				spec[today.get(Calendar.MONTH)][0]="일\t월\t화\t수\t목\t금\t토\t";
				spec[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]="";
				
				for (int f = 1; f <today.get(Calendar.DAY_OF_WEEK); f++) {
					spec[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+="\t";
				}
			}
			
			weeks[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+=today.get(Calendar.DATE)+"\t";
			
			String spStr = "";
			for(SpecData sd : sdArr) {
				
				if(sd.chk(today)) {
					spStr = sd.msg;	
					break;
				}
			}
			
			spec[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+=spStr+"\t";
			
			//마지막날 나머지 빈칸처리
			if(today.get(Calendar.DATE)==today.getActualMaximum(Calendar.DATE)) {
				//weeks[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+="마지막";

				for (int f = today.get(Calendar.DAY_OF_WEEK)+1; f <=7; f++) {
					weeks[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+="\t";
				}
				
				for (int f = today.get(Calendar.WEEK_OF_MONTH)+1; f <=6; f++) {
					weeks[today.get(Calendar.MONTH)][f]="\t\t\t\t\t\t\t";
				}
				
				for (int f = today.get(Calendar.DAY_OF_WEEK)+1; f <=7; f++) {
					spec[today.get(Calendar.MONTH)][today.get(Calendar.WEEK_OF_MONTH)]+="\t";
				}
				
				for (int f = today.get(Calendar.WEEK_OF_MONTH)+1; f <=6; f++) {
					spec[today.get(Calendar.MONTH)][f]="\t\t\t\t\t\t\t";
				}
				
			}
			
		}
		
		
		
		System.out.println("\n\n\n TYPE2 >>>>>\n");
		
		 for(int w = 0; w<=6; w++){
		    for( int m=0; m<12; m++){
			     // System.out.print(m+"_"+w+"\t\t");
		    	 System.out.print(weeks[m][w]+"\t\t");
			}
		    
		    System.out.println();
		 }
		 
		 
		 
		 
		 /*
			 * 1   2    3
			 * 1주
			 * 2주
			 * 3주
			 * 4주
			 * 5주
			 * 6주
			 * 
			 * 4	5	6
			 * 1주
			 * 2주
			 * 3주
			 * 4주
			 * 5주
			 * 6주
			 * 
			 * 7	8	9
			 * 1주
			 * 2주
			 * 3주
			 * 4주
			 * 5주
			 * 6주
			 * 
			 *10	11	12 
			 * 1주
			 * 2주
			 * 3주
			 * 4주
			 * 5주
			 * 6주
			 * 
			 * 
			 * 
			 * 
			 * for(큰달 :  1  -> 12  :  3씩){
				 * for(  주  : 1->6 ){
				 *     for( 작은달 : 큰달 -> 큰달+3){
				 *     
				 *     }
				 * }
			 * }
			 * 
			 * 주?
			 * 
			 * 
			 * */
		 
		 System.out.println("\n\n\n TYPE3 >>>>>\n");
		 for (int big = 0; big < weeks.length; big+=3) {
			
			for(int w = 0; w<=6; w++){
				for( int m= big; m<big+3; m++){
					
					 //System.out.print(m+"_"+w+"\t\t");
					 System.out.print(weeks[m][w]+"\t\t");
				}
			    
			    System.out.println();
			 }
			 System.out.println();
		 }
		 
		 
		 
		 System.out.println("\n\n\n TYPE4 >>>>>\n");
		 for (int big = 0; big < weeks.length; big+=3) {
			
			for(int w = 0; w<=6; w++){
				
				//날짜
				for( int m= big; m<big+3; m++){
					
					 //System.out.print(m+"_"+w+"\t\t");
					 System.out.print(weeks[m][w]+"\t\t");
				}
			    
			    System.out.println();
			    
			    
			    //spec
			    for( int m= big; m<big+3; m++){
					
					 System.out.print(spec[m][w]+"\t\t");
				}
			    
			    System.out.println();
			 }
			
			
			
			 System.out.println();
		 }
	}
	
	static SpecData [] sdArr = {
			
			new SpecData("5_5", "어린이날"),
			new SpecData("3_1", "삼일절"),
			new SpecData("11_18", "송탄절"),
			new SpecData("2_26", "지원일"),
			new SpecData("1_17", "개 강해"),
			new SpecData("6_15", "중일"),
			new SpecData("7_9", "전문대"),
			new SpecData("1_31", "설"),
			new SpecData("2_1", "-"),
			new SpecData("2_2", "날")
	};
	
}


class SpecData{
	
	String day, msg;

	public SpecData(String day, String msg) {
		super();
		this.day = day;
		this.msg = msg;
	}
	
	boolean chk(Calendar day) {
		String dayStr = (day.get(Calendar.MONTH)+1)+"_"+day.get(Calendar.DATE);
		
		return this.day.equals(dayStr);
	}
	
}



