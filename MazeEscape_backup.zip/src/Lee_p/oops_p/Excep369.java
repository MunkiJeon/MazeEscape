package oops_p;

public class Excep369 {

	public static void main(String[] args) {

		for (int i = 1; i <= 20; i++) {
			
			int one = i%10;
			int three = one%3;
			
			
			try {
				int a = 1234/three;
				System.out.println(i);
			} catch (Exception e) {
				
				try {
					int a = 1234/one;
					System.out.println("짝");
					
				} catch (Exception e2) {
					System.out.println(i);
				}
	
			}
						
		}

	}

}
