package oops_p;

abstract class ICPar{
	int a = 10;
	public void meth_1() {
		
	}
	
	abstract void meth_5();
}
class ICPar2{
	String a = "아기상어";
	void meth_1() {
		
	}
}

interface ICt_1{
	void meth_1() ;
	void meth_2() ;
}

interface ICt_2{
	void meth_3() ;
	void meth_2() ;
}

interface ICt_3{
	void meth_1() ;
	void meth_4() ;
}

interface ICtChild extends ICt_1, ICt_2{
	
}

class ICChild1 extends ICPar implements ICtChild,  ICt_3 {//,  ICPar2{

	
	public void meth_2() {
		// TODO Auto-generated method stub
		
	}

	
	public void meth_3() {
		// TODO Auto-generated method stub
		
	}

	
	public void meth_4() {
		// TODO Auto-generated method stub
		
	}
	
	public void meth_5() {
		// TODO Auto-generated method stub
		
	}
	
}


public class InterClassMain {

	public static void main(String[] args) {
		ICChild1 ic = new ICChild1();

	}

}
