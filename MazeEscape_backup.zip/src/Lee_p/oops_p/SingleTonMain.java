package oops_p;

class SingleAAA{
	int a = 10;
	String b = "티라노사우루스";
	
	public SingleAAA() {
		System.out.println("AAA 생성자 실행");
	}
	
	@Override
	public String toString() {
		return "SingleAAA [a=" + a + ", b=" + b + "]"+hashCode();
	}
}

class SingleBBB{
	int a = 1000;
	String b = "이구아노돈";
	
	static SingleBBB res = null;
	
	private SingleBBB() {
		System.out.println("BBB 생성자 실행");
	}
	
	static SingleBBB getInstance() {
		System.out.println("BBB getInstance() 실행");
		
		if(res==null) {
			res = new SingleBBB();
		}
		
		return res;
	}
	
	@Override
	public String toString() {
		return "SingleBBB [a=" + a + ", b=" + b + "]"+hashCode();
	}
}

public class SingleTonMain {

	public static void main(String[] args) {
		SingleAAA a1 = new SingleAAA();
		SingleAAA a2 = new SingleAAA();
		a1.a = 20;
		System.out.println(a1);
		System.out.println(a2);
		
		//SingleBBB b1 = new SingleBBB();
		SingleBBB b1 = SingleBBB.getInstance();
		SingleBBB b2 = SingleBBB.getInstance();
		System.out.println(b1);
		System.out.println(b2);
		b1.a = 2020;
		System.out.println(b1);
		System.out.println(b2);

	}

}
