package oops_p;

abstract class DyTpTT{
	String name;
	abstract void go(String dst, int dist);
}

class KAL extends DyTpTT{
	int kmh;
	public KAL(int kmh) {
		
		this.kmh = kmh;
		name = "비행기";
		
	}
	
	
	void go(String dst, int dist) {
		double hh = (double)dist/kmh;
		System.out.println(dst +"까지"+hh+" 시간으로 비행기 타고 가요");
	}
}

class Ship extends DyTpTT{
	String meal;
	
	public Ship(String meal) {
		
		this.meal = meal;
		name = "베";
		
	}
	
	@Override
	void go(String dst, int dist) {
		
		System.out.println(dst +"까지"+meal+" 먹으면서 항해해요");
	}
}


public class DyTransportationMain {

	public static void main(String[] args) {
		DyTpTT [] tts = {
			new DyTpTT() {
				int aaa = 1234;
				void asdf() {
					System.out.println("asdf 실행()");
				}
				
				void go(String dst, int dist) {
					
					asdf();
					
					System.out.println(dst +"까지"+dist+" 재정의 메소드 가요"+aaa);
				}
			},
			new KAL(800),
			new Ship("두리안"),
			new KAL(1000),
			new Ship("스테이크")
		};
		
		for (DyTpTT dt : tts) {
			dt.go("샌프란시스코", 9086);
		}
		//tts[0].asdf();
	}

}
