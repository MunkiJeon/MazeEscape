package oops_p;


class OverExam{

	String name, kind;
	int tot, res;
	
	OverExam(String name, int kor, int eng, int mat){
		kind = "일반";
		this.name = name;
		tot = kor + eng + mat;
		res = tot/3;
	}
	
	OverExam(String name, int kor, int eng, int mat, int art){
		kind = "예체능";
		this.name = name;
		tot = kor + eng + mat+ art;
		res = (int)(kor*0.2 + eng*0.1 + mat*0.15 + art*0.55);
	}

	@Override
	public String toString() {
		return kind + "\t" + name + "\t" + tot + "\t" + res;
	}
	
	
}


class Shape{
	
	String kind;
	int area, border;
	
	public Shape(int r) {
		kind = "원";
		area = (int)(Math.pow(r,2)*Math.PI);
		border = (int)(r*2*Math.PI);
	}
	
	public Shape(int w, int h) {
		kind = "직사각형";
		area = w*h;
		border = (w+h)*2;
	}
	
	public Shape(int w, int h, int a) {
		kind = "직각삼각형";
		area = w*h/2;
		border = w+h+a;
	}
	@Override
	public String toString() {
		return kind + ":" + area + " , " + border;
	}
	
	
}


public class OverExamMain {

	public static void main(String[] args) {
		OverExam [] studs = {
				
				new OverExam("현빈", 37,68, 92),
				new OverExam("원빈", 27,48, 62, 84),
				new OverExam("투빈", 97,68, 32),
				new OverExam("김우빈", 87,68, 42, 24),
				new OverExam("장희빈", 77,78, 72),
				new OverExam("젤리빈", 77,78, 72, 74),
				new OverExam("커피빈", 57,58, 52),
				new OverExam("미스터빈", 57,58, 52, 54),
				new OverExam("골빈", 27,38, 92),
				new OverExam("텅빈", 37,28, 22, 94)
		};
		
		for (OverExam oe : studs) {
			System.out.println(oe);
		}
		
		
		Shape [] shs = {
				new Shape(5),
				new Shape(5,6),
				new Shape(5,6,9),
				new Shape(10),
				new Shape(15,10),
				new Shape(15,10,26),
				new Shape(7),
				new Shape(7,8),
				new Shape(7,8,13)
				
		};
		/*
		for (Shape sh: shs) {
			System.out.println(sh);
		}*/
		
		for (int i = 0; i < shs.length; i++) {
			Shape sh = shs[i];
			//System.out.println(shs[i]);
			
			System.out.println(sh);
		}

	}

}


/*
 도형을 구현하세요
 
 도형종류		넓이						둘레
 원			반지름*반지름*원주율			반지름*2*원주율
 직사각형		가로*세로					(가로+세로)*2
 직각삼각형		가로+세로/2				가로+세로+빗변
 
 생성자를 오버로딩하여 구현
 
 출력내용 도형종류, 넓이, 둘레
 
 
 ---------------------------------------
 
 
 커피를 주문하세요

아메리카노(커피종류)  - 3000
카페라떼(커피종류, 우유량) - 3300
카라멜마끼아또(커피종류, 우유량, 카레멜 시럽) - 3500
카페모카(커피종류, 우유량, 휘핑있음없음) - 3500



각 커피별 주문 수량과 총금액을 출력하세요
 * */



