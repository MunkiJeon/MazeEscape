package swing_p;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class MousePostItMain extends JFrame implements MouseMotionListener, MouseListener {

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
		//System.out.println(e.getComponent().getX());
		System.out.println("Dragg:"+e.getX()+","+e.getY());
		
		pp.setLocation(pp.getX()-70+e.getX(), pp.getY()-20+e.getY());
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("move:"+e.getX()+","+e.getY());
	}
	ImageIcon icon;
	ImageIcon picon;
	
	JPanel pp;
	JLabel backLB;
	
	public MousePostItMain() {
		super("마우스포스트잇");
		setBounds(1920+50, 50, 900, 600);
		setLayout(null);
		
		icon =new ImageIcon("fff/post.png");
		picon =new ImageIcon("fff/post2.png");
		
		
		pp = new JPanel();
		pp.setLayout(null);
		pp.setBounds(50, 50, 170,170);
		
		JTextArea area = new JTextArea("나는 너고 너는 나다");
		area.setBounds(50, 50, 120,120);
		//area.setBackground(new Color(255,0,0,0));
		area.setOpaque(false);
		pp.add(area);
		
		backLB = new JLabel(icon);
		
		backLB.setBounds(0, 0, 170,170);
		pp.add(backLB);
		
		
		
		
		add(pp);
		
		setResizable(false);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pp.addMouseMotionListener(this);
		pp.addMouseListener(this);
	}

	public static void main(String[] args) {
		new MousePostItMain();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		backLB.setIcon(picon);

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		backLB.setIcon(icon);
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
