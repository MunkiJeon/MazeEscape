package swing_p;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

//이벤트핸들러 클래스 정의 -> ActionListener : 리스너에 해당하는 인터페이스
class MyBtnList implements ActionListener{
	
	JLabel label;
	JButton button;

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("눌렀다");
		label.setText("전문기 만세");
		label.setBackground(Color.blue);
		label.setForeground(Color.white);
		button.setEnabled(false);
		
		
	}
	
}

public class EventMain {

	public static void main(String[] args) {
		JFrame f = new JFrame("이벤트 발생");
		f.setBounds(1920+50, 50, 300,200);
		f.setLayout(new FlowLayout());
		
		JButton btn = new JButton("눌러바");
		JLabel lb = new JLabel("송지은 만세");
		lb.setOpaque(true);
		
		f.add(btn);
		f.add(lb);
		
		
		 MyBtnList mbl = new MyBtnList();
		 mbl.label = lb;
		 mbl.button = btn;
		 
		//btn:이벤트소스       				--> 버튼
		//addActionListener : 이벤트 리스너 --> 을 누르면
		//mbl : 이벤트 핸들러               --> actionPerformed: 눌렀다 출력
		btn.addActionListener(mbl);
		
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
