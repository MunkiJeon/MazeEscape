package swing_p;


import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class FontColorMain extends JFrame{

	public FontColorMain() {
		setBounds(1920+100, 50, 600, 600);
		
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		
		Font [] fs = ge.getAllFonts();
		for (Font ff : fs) {
			System.out.println(ff.getFontName());
		}
		
		String ttt = "그린 Com 01234 !@#$%^";
		
		Font [] ff = {
				
				new Font("휴먼매직체",Font.ITALIC, 30),
				new Font("휴먼둥근헤드라인",Font.ITALIC, 30),
				new Font("휴먼둥근헤드라인",Font.BOLD, 30),
				new Font("휴먼둥근헤드라인",Font.PLAIN, 30),
				new Font("휴먼옛체",Font.ITALIC, 30),
				new Font("휴먼옛체",Font.BOLD, 30),
				new Font("휴먼옛체",Font.PLAIN, 30),
				new Font("휴먼옛체",Font.ITALIC+Font.BOLD, 30),
				new Font("휴먼편지체",Font.ITALIC, 50),
				new Font("휴먼편지체",Font.ITALIC, 30),
				new Font("휴먼편지체",Font.ITALIC, 10)
		};
		
		Color [] cc ={
			Color.BLUE,
			Color.YELLOW,
			Color.GREEN,
			Color.RED,
			new Color(255, 0,0),
			new Color(255, 0,0, 100),
			new Color(255, 0,0, 50),
			new Color(255, 255,0),
			new Color( 0,255,0),
			new Color(0,0, 255),
			new Color(0, 0,0)
		};
		
		
		
		
		setLayout(new GridLayout(ff.length, 1));
		
		for (int i = 0; i < ff.length; i++) {
			JLabel lb = new JLabel(ttt);
			lb.setFont(ff[i]);
			lb.setForeground(cc[i]);
			lb.setBackground(new Color(255,200,200));
			lb.setOpaque(true);
			add(lb);
		}
		
		
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		
		new FontColorMain();

	}

	/* 무지개 색 을 표현하세요*/
}
