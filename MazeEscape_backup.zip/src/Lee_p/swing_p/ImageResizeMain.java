package swing_p;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class ImageResizeMain extends JFrame{
	
	Image img1, img2, img3;
	
	public ImageResizeMain() {
		super("이미지 크기변경");
		
		Toolkit kit = Toolkit.getDefaultToolkit();
		img1 = kit.getImage("fff/son_1.jpg");
		
		img2 = img1.getScaledInstance(270,480, Image.SCALE_SMOOTH);
		img3 = img1.getScaledInstance(200,200, Image.SCALE_SMOOTH);
		
		setBounds(1920+50, 50, 800, 600);
		setVisible(true);
		setResizable(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void paint(Graphics g) {
		if(img1==null) {
			return;
		}
		super.paint(g);
		
		g.drawImage(img1, 500,50,this);
		g.drawImage(img2, 0,0,this);
		g.drawImage(img3, 280,200,this);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ImageResizeMain();
	}

}
