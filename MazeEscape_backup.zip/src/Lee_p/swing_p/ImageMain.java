package swing_p;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;

import javax.swing.JFrame;

public class ImageMain extends JFrame{

	ArrayList<Image> imgs;
	ArrayList<Graphics> ggs;
	public ImageMain() {
		super("Image");
		imgs = new ArrayList<Image>();
		ggs = new ArrayList<Graphics>();
		setBounds(1920+50, 50, 800,600);
		
		setResizable(false);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		for (int i = 0; i < 3; i++) {
			//이미지 생성 : GUI 컨테이너 급에서 createImage 로 생성
			Image img = createImage(300, 200);
			// 이미지에 그릴 도구 가져오기
			// 화면을 그리고 나서 가져올수 있다  --> setVisible(true); 실행후에 처리해야함
			Graphics gg = img.getGraphics();
			
			imgs.add(img);
			ggs.add(gg);
		}
		
		
		
	
	}
	
	
		
	
	
	@Override
	public void paint(Graphics g) {
		
		if(imgs.get(0)==null) {
			return;
		}
		
		super.paint(g);
		ggs.get(0).setColor(Color.red);
		ggs.get(1).setColor(Color.yellow);
		ggs.get(2).setColor(Color.green);
		ggs.get(0).fillRect(50, 50, 150,80);
		ggs.get(1).fillOval(50, 50, 100,100);
		ggs.get(2).fillPolygon(
				new int[] {80,150,220},
				new int[] {150,50,150},
				3
				);
		
		g.drawImage(imgs.get(0), 50,0, this);
		g.drawImage(imgs.get(1), 400,0, this);
		g.drawImage(imgs.get(2), 50,300, this);
	}
	
	
	
	public static void main(String[] args) {
		
		new ImageMain();

	}

}
