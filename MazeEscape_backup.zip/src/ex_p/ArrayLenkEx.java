package ex_p;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayLenkEx {
/*56,78,92,45,78,25,77,94,77,56,83,85,56,45,27 
 * -> 수우미양가 구간으로 나누어 각구간 내림차순(높은점수순)으로 정렬하시오*/
	public static void main(String[] args) {
		int [] arr={56,78,92,45,78,25,77,94,77,56,83,85,56,45,27};
		List arr1 = new ArrayList();
		List arr2 = new ArrayList();
		for (int i = 0; i < arr.length; i++) {
			arr1.add(arr[i]);
		}
		Collections.sort(arr1);
		Collections.reverse(arr1);
		
		arr2.add("수");
		arr2.add(arr1.subList(0, 3));
		arr2.add("우");
		arr2.add(arr1.subList(4, 7));
		arr2.add("미");
		arr2.add(arr1.subList(8, 11));
		arr2.add("양");
		arr2.add(arr1.subList(12, 15));
		arr2.add("가");
		arr2.add(arr1.subList(12, 15));

		
		System.out.println(arr1);
		System.out.println(arr2);
		
//---------------------------------------------------------------
/*/////////학생 리스트를 정리하여 출력하세요
//// 학생 정보는 무작위로 입력되어 있음
/// 합격 점수 : 70
학생정보 : 반, 이름, 국, 영, 수, lol

//// 정리
반별 리스트       -> 합격/ 불합격
성별 리스트
반성별 리스트

/// 등수 순서대로 정리할 것*/
	
		Object [][] student = {
				{"반","1반","2반","3반"},
				{"이름","학생1","학생2","학생3","학생4","학생5","학생6","학생7",},
				{"점수",100,50,65,98,71,40,70},
				{"과목","국","영","수"},
				{"성별","남,여"}};
		Object [][] arr9999 = student;
		
		List l_arr = new ArrayList();
		
		double dd = 78.33333333333;double dd2 = 78.33333333333;
		double a =(double)(int)(dd*100)/100;
		
		System.out.println(dd);
		System.out.println(a);
		
		
	}
}
