package ex_p;

public class TryCatch_ex00 {
//1 2 짝 4 5 짝 7 8 짝 10 11 12 짝 14 15.....
	
//	조건문(분기문) 안쓰고!!
//1. 예외처리 1~100 369 
//2. 1~1000
//3. 지정된 숫자 일때 짝
	public static void main(String[] args) {
		String [] num=null;
		String [] ins= {"[369]","[369]{2}","[369]{3}"
						,"","",""};
		for (int i = 1; i <= 1000; i++) {
			num[i-1] = i+"";
			System.out.print(i+": ");
			int one = i%10;			//1의자리
			int one3 = one%3;		//1의자리 3
			
			int ten = i/10;			//10의자리
			int ten3 = ten%3;		//10의자리 3
			
			int hun = i%100;		//100의자리
			int hun3 = hun%100;		//100의자리 3

			try {
				int a = 10/one;
				
				try {
					int b = 10/one3;
					
					try {
						int c = 10/one;
						
						try {
							int d = 10/ten3;
							
						}catch (Exception e) {
							System.out.print("짝");
						}
					}catch (Exception e) {
						
					}
				}catch (Exception e) {
					
				}
			}catch (Exception e) {
				
			}
		}
	}
}
