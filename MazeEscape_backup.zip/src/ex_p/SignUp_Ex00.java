package ex_p;

import java.util.Scanner;
import java.util.regex.Pattern;

/*
//회원 가입 유효성 검사를 실시하세요
1. 아이디 : 영문 숫자 조합
2. 비번 , 비번확인 
3. 전화번호 - 숫자 : ###-####-####, ##(#)-###-####
4. 이름 (한글만 가능) 
5. 사진 첨부-->영문,숫자.이미지 확장자
이미지(jpg, jpeg, bmp, png, gif) -- 대소문자 구분없음
6. 우편번호 검색 - 구단위 (초성검색)
ㄱㅈ,광ㅈ,ㄱ진,광진,진,ㅈ,ㄱ,광
예외처리로 처리할 것 
* */

class Order{
	Scanner info = new Scanner(System.in);
	int var;
	String [][] comment = {
			{"ID를 입력해 주세요","ID는 4~10자 영문과 숫자로만 생성 가능합니다.","","ID 설정 완료!"},//id 확인용
			{"PW를 입력해 주세요","PW를 재 입력해 주세요","입력 하신 PW가 서로 다릅니다.","PW 설정 완료!"},//비번 확인용
			{"[0-9]{2,3}-[0-9]{3,4}-[0-9]{4}|[0-9]{6}-[0-9]{7}|0.[0-9]{9,11}"},//전화번호 확인용
			{"[가-힣]{2,6}"},//이름 확인용
			{"[a-zA-z0-9]{1,}.*[.](?i)(jpg|jpeg|bmp|png|gif)"}};
	String [] users_ins = {
			"[A-Za-z0-9]{4,10}",//id 확인용
			"",//비번 확인용
			"[0-9]{2,3}-[0-9]{3,4}-[0-9]{4}|[0-9]{6}-[0-9]{7}|0.[0-9]{9,11}",//전화번호 확인용
			"[가-힣]{2,6}",//이름 확인용
			"[a-zA-z0-9]{1,}.*[.](?i)(jpg|jpeg|bmp|png|gif)"};
	
	public Order(int var) {
		this.var = var;
		
		switch (var) {
		case 0:
			
			break;

		default:
			break;
		}
	}
	
}


enum Cart{
	ㄱ("[가-깋]"), ㄴ("[나-닣]"), ㄷ("[다-딯]"), ㄹ("[라-맇]"), ㅁ("[마-밓]"),
	ㅂ("[바-빟]"), ㅅ("[사-싷]"), ㅇ("[아-잏]"), ㅈ("[자-짛]"), ㅊ("[차-칳]"),
	ㅌ("[타-팋]"), ㅍ("[파-핗]"), ㅎ("[하-힣]");
	
	String s;

	Cart(String s) {
		this.s = s;
	}

}
enum Gu{	//서울시에 있는 구와 우편번호 정보	(우편번호는 임의값)
	
	종로("00001"), 중("00002"), 용산("00003"), 성동("00004"), 광진("00005"),
	동대문("00006"), 중랑("00007"), 성북("00010"), 강북("00011"), 도봉("00012"),
	노원("00013"), 은평("00014"), 서대문("00015"), 마포("00016"), 양천("00017"),
	강서("00020"), 구로("00021"), 금천("00022"), 영등포("00023"), 동작("00024"),
	관악("00025"), 서초("00026"), 강남("00027"), 송파("00030"), 강동("00031");
	
	String postNum;

	private Gu(String postNum) {
		this.postNum = postNum;
	}
}

class SearchLocalData{ //지역구 검색 데이터 베이스
	String [] localdata = "종로구,중구,용산구,성동구,광진구,동대문구,중랑구,성북구,강북구,도봉구,노원구,은평구,서대문구,마포구,양천구,강서구,구로구,금천구,영등포구,동작구,관악구,서초구,강남구,송파구,강동구".split(",");
}
public class SignUp_Ex00 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String id, pw, pnum, name, img, post;
		String [] users_ins = {
				"[A-Za-z0-9]{4,10}",//id 확인용
				"",//비번 확인용
				"[0-9]{2,3}-[0-9]{3,4}-[0-9]{4}|[0-9]{6}-[0-9]{7}|0.[0-9]{9,11}",//전화번호 확인용
				"[가-힣]{2,6}",//이름 확인용
				"[a-zA-z0-9]{1,}.*[.](?i)(jpg|jpeg|bmp|png|gif)"};
		
		while(true) {
			try {//아이디 입력 생성
				
				System.out.print("생성할 ID: ");
				id = sc.next();
				
				if(!Pattern.matches(users_ins[0], id)) {
					throw new Exception("ID는 4~10자 영문과 숫자로만 생성 가능합니다.");
					
				}
				
				System.out.println("사용할수있는 ID 입니다.");
				System.out.println();
				break;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
			
		}
//-----------------------------------------------------------------
		while(true) {	
			try {//비번 , 비번확인 
				
				System.out.print("2. PW: ");
				users_ins[1] = sc.next();
				System.out.println("비밀번호를 한번 더 입력하세요.");
				System.out.print("PW: ");
				String pwCheck = sc.next();
				
				if(!users_ins[1].equals(pwCheck)) {
					throw new Exception("비밀번호가 일치하지 않습니다.");
				}
				
				System.out.println("PW 설정 완료");
				System.out.println();
				break;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
		}
			
		while(true) {	
			try {//전화번호 입력
				System.out.print("3. 전화번호: ");
				pnum = sc.next();
				
				if(!(Pattern.matches(users_ins[2], pnum))) {
					throw new Exception("전화번호 형식이 바르지 않습니다.");
				}
				
				System.out.println("전화번호 입력 완료");
				System.out.println();
				break;
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
		}
		
		while(true) {		
			try {//이름 (한글만 가능)
				System.out.print("4. 이름: ");
				name = sc.next();
				
				if(!Pattern.matches(users_ins[3], name)){
					throw new Exception("이름에는 한글만 입력 가능합니다.");
				}
				
				System.out.println("이름 입력 완료");
				System.out.println();
				break;
			
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
		}
		
		while(true) {		
			try {//사진 첨부-->영문,숫자.이미지 확장자
//				   이미지(jpg, jpeg, bmp, png, gif) --  대소문자 구분없음
				System.out.print("5. 사진 파일명: ");
				img = sc.next();
				
				if(!Pattern.matches(users_ins[4], img)) {
					throw new Exception("파일 형식이 바르지 않습니다.");
				}
				
				System.out.println("사진 첨부 완료");
				System.out.println();
				break;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
		}
		
		while(true) {
			try {//우편번호 검색 - 구단위 (초성검색)
				//예) 광진구 > ㄱㅈ, 광ㅈ, ㄱ진, 광진, 진, ㅈ, ㄱ, 광 ...
				String pattern = ".*";
				
				System.out.print("6. 우편번호(구 입력): ");
				String letter = sc.next();
				
				if(!Pattern.matches("[ㄱ-ㅎ가-힣].*", letter)) {
					throw new Exception("구 이름을 한글로 입력하세요. (초성 포함 가능)");
				}
				
				char[] letterToChar = letter.toCharArray();	//입력받는 단어를 한자씩 나눠서
						
				for (int i = 0; i < letterToChar.length; i++) {
					if(Pattern.matches("[ㄱ-ㅎ]", letterToChar[i]+"")) {//초성이면 패턴에 ㄱ > [가-깋] 이런식으로 바꿔서 추가
						pattern += Cart.valueOf(letterToChar[i]+"").s;
					}
					else {//찐 한글이면 그냥 추가
						pattern += letterToChar[i];
					}
				}
				pattern += ".*";
				//>>이러면 예를들어 ㄱㅇ을 검색했을 때 패턴이 .*[가-깋][아-잏].* 이 됨
				
				int cnt = 0;
				post = "";
				Gu[] guArr = Gu.values();
				
				//우편번호 정보에서 구 이름을 찾아서 패턴과 일치하면 구 이름과 우편번호 출력
				for (int i = 0; i < guArr.length; i++) {
					if(Pattern.matches(pattern, guArr[i]+"")) {
						System.out.print(guArr[i]+"구: ");
						System.out.println(Gu.valueOf(guArr[i]+"").postNum);
						cnt++;
						post = Gu.valueOf(guArr[i]+"").postNum;
					}
				}
				System.out.println();
				
				//만약에 검색했는데 결과값이 하나면 그 구의 우편번호를 회원 정보에 입력
				if(cnt==1) {
					System.out.print("우편번호 입력 완료");
					System.out.println();
					break;
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println();
			}
		}
	}

}
