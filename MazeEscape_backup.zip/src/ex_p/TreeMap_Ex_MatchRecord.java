package ex_p;

import java.util.*;

/*////// 오늘 경기 기록을 출력하세요
/// 입력: "h22","h23","h11","a3","a7","a22","h23","a11","h5","a3","h8","a11","h22","h23"..........

/// 출력내용

//  h : 홈팀,  a:상대팀

//  각 팀별로 선수가 안타를 친 갯수를 출력하세요

//  단 선수번호는 오름차순으로 정렬

ex)

홈팀

22 : 2

23 : 3

...

상대팀

3 : 2

7 : 1

....
 * */
//class TMScore implements Comparable{
//	
//}
public class TreeMap_Ex_MatchRecord {

	public static void main(String[] args) {
		
				String [] score = {"h22","h23","h11","a3","a7","a22","h23","a11","h5","a3","h8","a11","h22","h23"};
		
		TreeMap<String, TreeMap<String, Integer>> H_A_Team = new TreeMap<String, TreeMap<String, Integer>>();
		//받을 트리맵의 모양을 ( 키 (문자열) : 트리멥 ( 문자열 : 숫자) ) 만듬

		for (int i = 0; i < score.length; i++) {
			String team = score[i].charAt(0)+"";	// 팀 구분자 분리
			String p_num = score[i].substring(1); 	// 선수 구분자 분리
			TreeMap<String, Integer> player = new TreeMap<>(); //내부 트리맵 선수 : 안타 횟수
			
			int cnt = 1;	//안타 횟스 초기화 및 추가
			
			if(!H_A_Team.containsKey(team)) {
				H_A_Team.put(team, player);
			}
			if((H_A_Team.get(team).containsKey(p_num))) {
				cnt += (H_A_Team.get(team)).get(p_num);
			}
			(H_A_Team.get(team)).put(p_num, cnt);
			
//			if((H_A_Team.get("h").get(team_num))!=null) {
//				System.out.println((H_A_Team.get("h").get(team_num)));
//			}
//			System.out.println((H_A_Team.get("h").get(team_num)));
		}
		
		System.out.println("Home팀");
		System.out.println(H_A_Team.get("h"));
		System.out.println("Away팀");
		System.out.println(H_A_Team.get("a"));
		
		for (String team : H_A_Team.keySet()) {
			System.out.println("["+team+"팀]");
			for (String player : H_A_Team.get(team).keySet()) {
				System.out.println(player+"번 선수: "+H_A_Team.get(team).get(player)+"개");
			}
			System.out.println();
		}
			
	}
	

}