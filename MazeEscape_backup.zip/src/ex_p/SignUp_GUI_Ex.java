package ex_p;
import java.awt.Color;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.util.*;
import javax.imageio.ImageReader;
import javax.swing.*;

public class SignUp_GUI_Ex {
static int Main_f_h, Main_f_w;

	public static void main(String[] args) {
//--------------메인창 
		JFrame Main_f = new JFrame("LogIn");	//창이름
		
		Main_f.setVisible(true);				//창 보임 유무
		Main_f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	//창의 X표시 누르면 닫기
		Main_f.setBounds(700,50,500,760);		//좌표+크기 지정 (X,Y - 좌표,X,Y - 크기 )	
		Main_f.setLayout(null); 				//창에 맞춰 위치 초기화	
		Main_f_h = Main_f.getHeight();
		Main_f_w = Main_f.getWidth();
//--------------로그인 구역
		JLabel IdPwLB = new JLabel("회원 정보 입력");
		IdPwLB.setBounds(20, 5, 100,20);
		Main_f.add(IdPwLB);
		JLabel IdLB = new JLabel("ID    :");
		IdLB.setBounds(5, 30, 50,20);
		Main_f.add(IdLB);
		JLabel PwLB = new JLabel("PW :");
		PwLB.setBounds(5, 60, 50,20);
		Main_f.add(PwLB);
		JLabel PwChLB = new JLabel("PW Ch :");
		PwChLB.setBounds(5, 90, 50,20);
		Main_f.add(PwChLB);
		
		JTextField id = new JTextField();
		id.setBounds(60,30,100,20);
		Main_f.add(id);
		JPasswordField pw = new JPasswordField();
		pw.setBounds(60,60,100,20);
		Main_f.add(pw);
		JPasswordField pwch = new JPasswordField();
		pwch.setBounds(60,90,100,20);
		Main_f.add(pwch);
//--------------개인정보 구역
		JLabel goboon0 = new JLabel("--------------------------------------");
		goboon0.setBounds(5, 110, 300,10);
		Main_f.add(goboon0);
		
		JLabel User_t = new JLabel("회원 정보 입력");
		User_t.setBounds(5, 120, 100,20);
		Main_f.add(User_t);
		
		JLabel Name_t = new JLabel("이름 :");
		Name_t.setBounds(5, 150, 100,20);
		Main_f.add(Name_t);
		JTextField Name_in = new JTextField();
		Name_in.setBounds(60,150,100,20);
		Main_f.add(Name_in);
		
		JLabel P_num_t = new JLabel("전화 :");
		P_num_t.setBounds(5, 180, 100,20);
		Main_f.add(P_num_t);
		JTextField P_num_in = new JTextField();
		P_num_in.setBounds(60,180,100,20);
		Main_f.add(P_num_in);
		
//		JLabel goboon1 = new JLabel("--------------------------------------");
//		goboon1.setBounds(5, 110, 300,10);
//		Main_f.add(goboon1);
		
//--------------배경 	
		ImageIcon icon = new ImageIcon("fff\\sharkbar.jpg");
		
		JButton back = new JButton("",icon);
		back.setBounds(-100, 0, Main_f_h,Main_f_w);
		back.setEnabled(false);
		back.setVerticalTextPosition(0);
		back.setHorizontalTextPosition(0);
		Main_f.add(back);
	}

}
