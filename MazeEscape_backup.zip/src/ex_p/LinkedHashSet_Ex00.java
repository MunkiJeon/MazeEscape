package ex_p;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

//2. 도형을 정렬하여 출력하세요
//정렬순서  : 도형이름(오름차순), 넓이(내림차순), 둘레(내림차순) // 모두 같을 경우 생략 
// 
class Shape{
	String kind;
	int area, border;
	
	public Shape(String kind, int area, int border) {
		super();
		this.kind = kind;
		this.area = area;
		this.border = border;
	}

	@Override
	public String toString() {
		return  "명칭 :" + kind + "| 넓이 :" + area + "| 둘레 :" + border;
	}
	public Shape(int r) {//원
		
		kind = "원";
		double pi = 3.141592;
		area = (int)(r * r * pi);
		border = (int)(r * 2 * pi);
	}
	
	public Shape(int w, int h) {//직사각형
		
		kind = "직사각형";
		
		area = w * h;
		border = (w + h) * 2;
	}
	
	public Shape(int w, int h, int a) {//직각삼각형
		
		kind = "직각삼각형";
		
		area = w * h / 2;
		border = w + h + a;
	}
	
	
}

class TreeMemShape implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Shape me = (Shape)o1;
		Shape you = (Shape)o2;
		
		int res = me.kind.compareTo(you.kind);
		if(res==0) {
			res = you.area-me.area;
		}
		if(res==0) {
			//res = 1;
			res = you.border-me.border;
		}
		System.out.println(res);
		return res;
	}
	
	
}
public class LinkedHashSet_Ex00 {

	public static void main(String[] args) {
		
		Set s5 = new TreeSet(new TreeMemShape());
		s5.add(new Shape(5));
		s5.add(new Shape(3,5));
		s5.add(new Shape(2,5));
		s5.add(new Shape(7,6,5));
		s5.add(new Shape(5));
		s5.add(new Shape(3,5));
		s5.add(new Shape(5,5));
		s5.add(new Shape(7,7,5));
		s5.add(new Shape(9));
		s5.add(new Shape(5,5));
		s5.add(new Shape(7,5));
		s5.add(new Shape(7,7,7));
		s5.add(new Shape(7,5));
		s5.add(new Shape(2,5));
		System.out.println("--------------------");
		for (Object obj : s5) {
			System.out.println(obj);
		}
	}

}
