package ex_p;

import javax.swing.JOptionPane;
import java.util.ArrayList;

/*
풀이한 Quiz 를 기반으로  

1. 패스를 구현해 주세요 

2. 정답이 아닐 경우 맞출때까지 문제를 풀게 해 주세요

3. 패스 한 경우 오답을 패스 이전 대답으로 할게 해주세요
*/

class ThQuizTimer extends Thread{
	
	boolean chk = false;

	@Override
	public void run() {
		for (int i = 30; i> 0; i--) {
			if(chk) {
				break;
			}
			try {			
				System.out.println(i+","+chk);
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
		chk = true;
		System.out.println("타이머 종료");		
	}
}

class ThQuiz extends Thread{
	
	ThQuizTimer timer;	
	ArrayList<ThQuizData> arr;
	
	public ThQuiz(ThQuizTimer timer, ThQuizData... arr) {
		super();
		this.timer = timer;
		this.arr = new ArrayList<ThQuizData>();
		
		for (ThQuizData qData : arr) {
			this.arr.add(qData);
		}
	}

	@Override
	public void run() {	
		int jum = 0;
		for (ThQuizData qd : arr) {
			while (!timer.chk) {// 타이머 끝날때가지 질문 무한 반복
				String input = JOptionPane.showInputDialog(qd.qq);
				if(timer.chk) {			
					input ="시간경과";
					break;
				}
				if(qd.answer.equals(input)) {	//정답 입력시
					System.out.println(qd.qq+": 답:"+input);
					jum+=20;					//점수 주고
					break;						//반복 한꺼풀 나가고
				}else if(input.equals("pass")||input.equals("")){	//pass 혹은 미입력시
					System.out.println(qd.qq+":"+"패스 하셨습니다..."+"(답:"+qd.answer+")");
					break;						//반복 한꺼풀 나가고
				}else {							//오답 입력시
					System.out.println(qd.qq+":"+input+" = 오답 다시!!!");
					continue;					//질문 무한 반복
				}
			}
		}		
		timer.chk = true;
		System.out.println("시험점수:"+jum);
	}
}
class ThQuizData{
	String qq, answer;
	public ThQuizData(String qq, String answer) {
		super();
		this.qq = qq;
		this.answer = answer;
	}	
}

public class ThreadQuiz_Ex {
	public static void main(String[] args) {
		ThQuizTimer timer = new ThQuizTimer();
		ThQuiz quiz =new ThQuiz(timer,
				new ThQuizData("감자 One-Piece 선원(팀원,조원) 수는?", "5"),
				new ThQuizData("자음의 개수 는?", "14"),
				new ThQuizData("모음의 개수 는?", "10"),
				new ThQuizData("한국의 수도 는?", "서울"),
				new ThQuizData("강사님의 닉네임은?", "네모장군"));
		//quiz.timer = timer;
		timer.start();
		quiz.start();
	}
}
