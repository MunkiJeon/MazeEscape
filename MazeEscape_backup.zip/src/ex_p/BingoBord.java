package ex_p;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class BingoBord {

	public static void main(String[] args) {
/*구현할 기능
 * 보드판 => '*' 로 일단 가려짐
 * 번호판 => 랜덤으로 저장되어있다가 위치 밣혀지면 번호 온
 * */
		Set s1 = new HashSet();
		ArrayList bord_arr = new ArrayList();
		ArrayList num_arr = new  ArrayList();
		
		for (int i = 0; i < 4; i++) {
			int no =(int)(Math.random()*100)+1;
			num_arr.add(no);
			bord_arr.add(no);
			
			if(num_arr.size()==7)
				break;
		}
		
		System.out.println("lotto1:"+num_arr);
		System.out.println("lotto2:"+bord_arr);
		
		
		Set bingo = new HashSet();
		
		while(bingo.size()<25) {
			int no = (int)(Math.random()*100+1);
			bingo.add(no);
		}
		
		//System.out.println(bingo);
		int i = 0;
		for (Object oo : bingo) {
			i++;
			System.out.print(oo+"\t");
			
			if(i%5==0) {
				System.out.println();
			}
		}
	
	
	}

}
