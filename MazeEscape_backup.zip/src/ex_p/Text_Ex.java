package ex_p;

import java.text.DecimalFormat;

public class Text_Ex {
	public static void main(String[] args) throws Exception {
	
		DecimalFormat intfo = new DecimalFormat();
		int [] jum = {67,78,89,98,76,54,78,77,90,56};
		
		String [] ppArr ={
				"▲ ;▼ "
		};
		for(String pp: ppArr) {
			System.out.println(pp+">>>>>>>>");
			intfo=new DecimalFormat(pp);
			
			for (int in : jum) {
				int in_set = jum[in]-70;
				System.out.println(in+" : "+intfo.format(in));
			}
		}
		
	}
}
