package ex_p;

import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;


public class Mineral_Water_Ex {
	//다음 숫자들의 각 약수들의 갯수를 구하세요 단 0,1 제외
	 
	
	public static void main(String[] args) {
		
		class Comp00{
			int num_A;

			public Comp00(int num_A) {
				super();
				this.num_A = num_A;
			}
			public int compareTo(Object o) {
				Comp00 you = (Comp00)o;
				
				int res = num_A - you.num_A;
			
				return res;
				
			}
		}
		int [] nums = {22,4,56,7,8,90,12,3,45,6,22,31,45,63,86,57};
		
		HashMap map = new HashMap();
		
		for (int i = 0; i < nums.length; i++) {
			int num_cal = nums[i];
			
			for (int j = 2; j < num_cal; j++) {
				int cnt=1;
				if (num_cal%j == 0) {
					if(map.containsKey(j)) {
						cnt+=(int)map.get(j);		
					}
					map.put(j, cnt);	
				}	
			}	
		}
		
		
				//System.out.println(kk);
				
		for (Object k : new TreeSet( map.keySet())) {
	
			System.out.println(k+":"+map.get(k));
		}
	}
}
