package ex_p;


import java.awt.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.*;
/*잠금, 계정, 아이콘 변경*/

public class Task_Bar_Swing_Ex extends JFrame{
	
	Date today = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd (E) a HH:mm");
	String Time = sdf.format(today);
	
	public Task_Bar_Swing_Ex(String name) {
		super(name);
		setLayout(new BorderLayout());
		setBounds(100,50,600,400);			//배경 좌표+크기 지정 (X,Y - 좌표,X,Y - 크기 )
		
//		setFont(new Font("휴먼둥근헤드라인",Font.PLAIN, 15)); //내부 폰트지정 - 실패
		ImageIcon [] icon_zip = {
				//-----------------"잠금" 아이콘 
				//-----------------"시작" 안의 아이콘 
				 new ImageIcon("fff/icon/user.png"),
				 new ImageIcon("fff/icon/file-20.png"),
				 new ImageIcon("fff/icon/image-20.png"),
				 new ImageIcon("fff/icon/settings-20.png"),
				//-----------------"시작" 안, "종료" 아이콘 
				 new ImageIcon("fff/icon/power-saving.png"),
				 new ImageIcon("fff/icon/reboot.png"),
				 new ImageIcon("fff/icon/power-off.png"),
				//-----------------"검색" 안의 파일 아이콘 
				 new ImageIcon("fff/icon/file-20 (1).png"),
				//-----------------"폴더" 안의 아이콘
				 new ImageIcon("fff/icon/search-20.png"),
				 new ImageIcon("fff/icon/folder-20.png"),
				//-----------------"크롬" 안의 아이콘 
				 new ImageIcon("fff/icon/chrome-20.png"),
				 new ImageIcon("fff/icon/pin.png"),
				 new ImageIcon("fff/icon/cross-20.png")
		};
		
		JDialog dd = new JDialog(this, "로그인창", true);
		//true = Domodal : 현재 창을 닫아야 오더창 열림
		//false = Modaless : 현재 창과 상관 없이 오더 창 열림
		dd.setBounds(300, 250, 300, 200);
		dd.setLayout(new BorderLayout());
        dd.add(new JButton("로그인",icon_zip[0]),"Center");
        dd.setVisible(true);
		
		JMenuBar bar =new JMenuBar();	//작업 표시줄 뼈대
		bar.setBackground(Color.DARK_GRAY);
		//----------------------"시작" 영역	
		JMenu win = new JMenu("시 작");
		win.setForeground(Color.WHITE);
		JMenuItem m1_0 = new JMenuItem("계 정",icon_zip[0]);
		JMenuItem m1_1 = new JMenuItem("문 서",icon_zip[1]);
		JMenuItem m1_2 = new JMenuItem("사 진",icon_zip[2]);
		JMenuItem m1_3 = new JMenuItem("설 정",icon_zip[3]);
		JMenu m1_4 = new JMenu("종 료");
		//----------------------"종료" 내부
		m1_4.add(new JMenuItem("절 전",icon_zip[4]));
		m1_4.add(new JMenuItem("시스템 종료",icon_zip[5]));
		m1_4.add(new JMenuItem("다시시작",icon_zip[6]));
		
		win.add(m1_0);//시작에 아이템 넣기
		win.add(m1_1);
		win.add(m1_2);
		win.add(m1_3);
		win.add(m1_4);
		//----------------------"검색" 영역
		JMenu sea = new JMenu("검 색");
		sea.setForeground(Color.WHITE);
		sea.setLayout(new GridLayout(1,6,1,3));
		
		JTextField m2_1 = new JTextField("검색"); //검색창
		sea.add(m2_1);
		sea.addSeparator();
		sea.add(new JLabel(" 최근 파일 "));
		for (int i = 1; i <= 7; i++) {
			sea.add(new JButton("파일_"+i+".java",icon_zip[7]));
		}
		//----------------------"폴터" 영역
		JMenu fol = new JMenu("폴 더");
		fol.setForeground(Color.WHITE);
		
		fol.add(new JMenuItem("파일 탐색기",icon_zip[8]));
		fol.addSeparator();
		fol.add(new JLabel("최근 파일"));
		for (int i = 1; i <=7; i++) {
			fol.add(new JButton("폴더_"+i,icon_zip[9]));
		}
		//----------------------"크롬" 영역
		JMenu chr = new JMenu("크 롬");
		chr.add(new JMenuItem("새 창",icon_zip[10]));
		chr.add(new JMenuItem("작업 표시줄 제거",icon_zip[11]));
		chr.add(new JMenuItem("창 닫기",icon_zip[12]));
		chr.setForeground(Color.WHITE);
		
		//----------------------"숨겨진 아이콘" 영역
		JMenu Hidden = new JMenu("▼");
		Hidden.setLayout(new GridLayout(3,3,3,3));
		Hidden.add(new JMenuItem("",icon_zip[10]));
		Hidden.add(new JMenuItem("",icon_zip[9]));
		Hidden.add(new JMenuItem("",icon_zip[7]));
		Hidden.setForeground(Color.WHITE);
		
		JMenu Time_a = new JMenu(Time);
		Time_a.setForeground(Color.WHITE);
		bar.add(win); //작업 표시줄에 항목들 넣기
		bar.add(sea);
		bar.add(fol);
		bar.add(chr);
		bar.add(new JLabel("__________________________________"));
		bar.add(Hidden);
		bar.add(Time_a);

		add("North",bar);
		JPanel back  = new JPanel();
		back.setBackground(new Color(36, 252, 255,60));
		
//		JButton back = new JButton("",icon_zip[0]); //버튼을 배경으로 쓴 시도...
//		back.setEnabled(true);
		add("Center",back);
		
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		new Task_Bar_Swing_Ex("윈도우 작업 표시줄");
	}

}
