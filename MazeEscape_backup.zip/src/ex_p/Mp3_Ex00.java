package ex_p;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

//mp3 노래듣기를 구현하세요
// 1. 노래 정보 :  트랙번호, 노래제목, 가수
// 2. 노래 리스트 -->next 에 넣기
// 3. 구현내용 다음곡, 이전곡, 트랙번호
//-------------------------------------------------------------
//검색기능을 구현하세요
//1. 제목으로 검색
//2. 현재 트랙 이후부터 검색
//3. 제목, 가수를 구분하여 검색
//   ---  동일 검색내용이 있을 경우 
//          1. 현재 트랙 바로 다음 나오는 곡으로 이동
//          2. 검색된 노래 정보를 보여주고 트랙번호를 입력하여 선택하여 이동
class MP3{
	String [][] M_list = {
/*트랙번호 -> 인덱스 위치*/	
/*노래제목*/	{"노래1","노래2","노래3","노래4","노래5","노래6","노래7","노래8","노래9","노래10"},
/*가수이름*/	{"가수1","가수2","가수3","가수4","가수5","가수6","가수7","가수8","가수9","가수10"}};
	String now = null;
	Stack back = new Stack();
	Stack next = new Stack();
	Queue Playlist = new LinkedList();
	void PowerOn(){
		for (int i = 0; i < M_list[0].length; i++) {
			Playlist.offer(M_list[0][i]+"-"+M_list[1][i]);
		}
		if (now == null) {
			now =M_list[0][0]+M_list[1][0];
			next.push(M_list[0][1]+M_list[1][1]);
		}
		
		ppp();
	}
	
	
	
	
	void ppp() {
		System.out.println("PlayList :"+Playlist);
		System.out.println("이전 : "+back+"| 현재 :"+now+"| 다음 : "+next);
		System.out.println();
	}
}
public class Mp3_Ex00 {

	public static void main(String[] args) {
		MP3 mp = new MP3();
		mp.PowerOn();
		

	}

}
