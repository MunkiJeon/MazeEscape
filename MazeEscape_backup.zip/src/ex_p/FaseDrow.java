package ex_p;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JFrame;

public class FaseDrow extends JFrame implements MouseListener{
	public FaseDrow() {
		super("paint");
		System.out.println("생성자다!!!");
		
		setBounds(50, 50, 900, 600);
		setLayout(null);
		setVisible(true);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
//	ArrayList F_L_x = new ArrayList();
//	ArrayList F_L_y = new ArrayList();
	int[] arrX, arrY;
	int i = 0;
	@Override
	public void paint(Graphics g) {
		super.paint(g); 
		
//		g.setColor(Color.black);
//		
//		g.drawPolygon(
//				F_L_x,
//				F_L_y,
//				F_L.size()
//				F_L_x.size()
//				);
//		
//		addMouseListener(this);
		
		g.drawPolygon(
				new int[] {314,358,432,479,445,419,386,360,347},
				new int[] {235,223,215,288,354,372,373,359,302},
				9
				);
		
		addMouseListener(this);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FaseDrow();
	}
@Override
public void mouseClicked(MouseEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void mousePressed(MouseEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void mouseReleased(MouseEvent e) {
	System.out.println(e.getX()+","+e.getY());
//	arrX[i] = e.getX();
//	arrY[i] = e.getY();
	
}
@Override
public void mouseEntered(MouseEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public void mouseExited(MouseEvent e) {
	// TODO Auto-generated method stub
	
}

}
